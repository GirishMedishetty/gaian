--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2 (Debian 15.2-1.pgdg110+1)
-- Dumped by pg_dump version 15.2 (Debian 15.2-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64)
);


ALTER TABLE public.admin_event_entity OWNER TO gaian;

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO gaian;

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO gaian;

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO gaian;

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO gaian;

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO gaian;

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO gaian;

--
-- Name: client; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO gaian;

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO gaian;

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO gaian;

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO gaian;

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO gaian;

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO gaian;

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO gaian;

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO gaian;

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO gaian;

--
-- Name: client_session; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_session (
    id character varying(36) NOT NULL,
    client_id character varying(36),
    redirect_uri character varying(255),
    state character varying(255),
    "timestamp" integer,
    session_id character varying(36),
    auth_method character varying(255),
    realm_id character varying(255),
    auth_user_id character varying(36),
    current_action character varying(36)
);


ALTER TABLE public.client_session OWNER TO gaian;

--
-- Name: client_session_auth_status; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_session_auth_status (
    authenticator character varying(36) NOT NULL,
    status integer,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_auth_status OWNER TO gaian;

--
-- Name: client_session_note; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_session_note (
    name character varying(255) NOT NULL,
    value character varying(255),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_note OWNER TO gaian;

--
-- Name: client_session_prot_mapper; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_session_prot_mapper (
    protocol_mapper_id character varying(36) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_prot_mapper OWNER TO gaian;

--
-- Name: client_session_role; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_session_role (
    role_id character varying(255) NOT NULL,
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_session_role OWNER TO gaian;

--
-- Name: client_user_session_note; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.client_user_session_note (
    name character varying(255) NOT NULL,
    value character varying(2048),
    client_session character varying(36) NOT NULL
);


ALTER TABLE public.client_user_session_note OWNER TO gaian;

--
-- Name: component; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO gaian;

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.component_config OWNER TO gaian;

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO gaian;

--
-- Name: credential; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.credential OWNER TO gaian;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO gaian;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO gaian;

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO gaian;

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255),
    details_json_long_value text
);


ALTER TABLE public.event_entity OWNER TO gaian;

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024)
);


ALTER TABLE public.fed_user_attribute OWNER TO gaian;

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO gaian;

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO gaian;

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO gaian;

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO gaian;

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO gaian;

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO gaian;

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO gaian;

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO gaian;

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO gaian;

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO gaian;

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL
);


ALTER TABLE public.identity_provider OWNER TO gaian;

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO gaian;

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO gaian;

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO gaian;

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36)
);


ALTER TABLE public.keycloak_group OWNER TO gaian;

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO gaian;

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO gaian;

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL
);


ALTER TABLE public.offline_client_session OWNER TO gaian;

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.offline_user_session OWNER TO gaian;

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO gaian;

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO gaian;

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO gaian;

--
-- Name: realm; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO gaian;

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO gaian;

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO gaian;

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO gaian;

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO gaian;

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO gaian;

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO gaian;

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO gaian;

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO gaian;

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO gaian;

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO gaian;

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO gaian;

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO gaian;

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO gaian;

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO gaian;

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO gaian;

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO gaian;

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO gaian;

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO gaian;

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO gaian;

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO gaian;

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO gaian;

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO gaian;

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO gaian;

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL
);


ALTER TABLE public.user_attribute OWNER TO gaian;

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO gaian;

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO gaian;

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO gaian;

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO gaian;

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO gaian;

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO gaian;

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO gaian;

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO gaian;

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO gaian;

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO gaian;

--
-- Name: user_session; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_session (
    id character varying(36) NOT NULL,
    auth_method character varying(255),
    ip_address character varying(255),
    last_session_refresh integer,
    login_username character varying(255),
    realm_id character varying(255),
    remember_me boolean DEFAULT false NOT NULL,
    started integer,
    user_id character varying(255),
    user_session_state integer,
    broker_session_id character varying(255),
    broker_user_id character varying(255)
);


ALTER TABLE public.user_session OWNER TO gaian;

--
-- Name: user_session_note; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.user_session_note (
    user_session character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(2048)
);


ALTER TABLE public.user_session_note OWNER TO gaian;

--
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


ALTER TABLE public.username_login_failure OWNER TO gaian;

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: gaian
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO gaian;

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
78aac6ea-271f-4a33-860e-37f9a9da06bb	e4cd3c3a-b093-40aa-9bb4-2bb2d8ec9a62
5e886ca6-0cf6-47fb-8cfd-c14d2e323ae5	b6334ce6-a38e-4c63-a834-c04917885c4e
fd00e3d6-ed90-4faa-b279-ed8da558fdb1	6ecddc8f-729b-4b64-93be-e851e345c0fc
73b631ec-69cd-4a9d-9568-130374c0e5c0	e65221f4-8bce-4074-a82d-deb6af0bb80f
aedc057b-7202-46f5-9478-7ef82f0e3a54	67cbece1-f2be-404f-90fb-ae7af173b61e
7daf3601-074b-4ab9-babe-6c4712df1a99	ea8535a9-b65d-4012-a40a-b1bdd73b29b1
1cb8b12c-78f4-4090-a0ea-89f070199e16	6a1dba2e-1e31-4673-aaf7-44a705f8793d
bc89b137-11a8-42d4-9128-189775120a67	456adab1-163b-42ed-81a3-dd5dfa87aba2
c2a5d1a5-f3c5-4c62-84e4-4a4838523125	f874c5ea-c81b-4dc1-87c6-3b70d355dec3
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
45f96fd7-5e64-4397-838c-4436a189e08e	\N	auth-cookie	962fdb71-b4bb-438b-80ec-044eefbde5ed	f532034b-33f6-4990-902f-0ab96143fd4b	2	10	f	\N	\N
9139589e-a9de-4c42-8ca6-70ce01a7be2c	\N	auth-spnego	962fdb71-b4bb-438b-80ec-044eefbde5ed	f532034b-33f6-4990-902f-0ab96143fd4b	3	20	f	\N	\N
d008bb51-f28f-403b-a139-935bb4d927a1	\N	identity-provider-redirector	962fdb71-b4bb-438b-80ec-044eefbde5ed	f532034b-33f6-4990-902f-0ab96143fd4b	2	25	f	\N	\N
5345f8e3-c55f-4f56-82dd-9a5e14c190eb	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	f532034b-33f6-4990-902f-0ab96143fd4b	2	30	t	c415bfdc-43dc-4115-8e72-d8f49f1f0ea1	\N
48d37e36-410d-4cb1-bab2-682cb884f155	\N	auth-username-password-form	962fdb71-b4bb-438b-80ec-044eefbde5ed	c415bfdc-43dc-4115-8e72-d8f49f1f0ea1	0	10	f	\N	\N
ea33579e-d167-4da5-94cd-07fa13fe11c1	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	c415bfdc-43dc-4115-8e72-d8f49f1f0ea1	1	20	t	e8ffcedd-2934-46d0-83cb-d1d706720ef5	\N
b12871fa-fb6e-40b8-9982-2458b40e1402	\N	conditional-user-configured	962fdb71-b4bb-438b-80ec-044eefbde5ed	e8ffcedd-2934-46d0-83cb-d1d706720ef5	0	10	f	\N	\N
5cb89216-85b3-4ed8-ad5f-a2373300d5c0	\N	auth-otp-form	962fdb71-b4bb-438b-80ec-044eefbde5ed	e8ffcedd-2934-46d0-83cb-d1d706720ef5	0	20	f	\N	\N
4ea698c2-b55b-449d-8bad-67afe35a1354	\N	direct-grant-validate-username	962fdb71-b4bb-438b-80ec-044eefbde5ed	9102a116-9395-4461-a523-1635819d3d5e	0	10	f	\N	\N
f60c6a3b-006c-47c8-85f8-73ffebadb8b8	\N	direct-grant-validate-password	962fdb71-b4bb-438b-80ec-044eefbde5ed	9102a116-9395-4461-a523-1635819d3d5e	0	20	f	\N	\N
af1c53a5-280f-4a6f-a196-72b691388590	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	9102a116-9395-4461-a523-1635819d3d5e	1	30	t	9de04031-d636-4647-a7fc-65077651b11a	\N
6b021313-b001-48ce-8e9f-608df2d31133	\N	conditional-user-configured	962fdb71-b4bb-438b-80ec-044eefbde5ed	9de04031-d636-4647-a7fc-65077651b11a	0	10	f	\N	\N
b08fc11e-211d-42e1-9726-fbc8e7860094	\N	direct-grant-validate-otp	962fdb71-b4bb-438b-80ec-044eefbde5ed	9de04031-d636-4647-a7fc-65077651b11a	0	20	f	\N	\N
6528c471-b0d7-485e-9e88-ac204b778f1c	\N	registration-page-form	962fdb71-b4bb-438b-80ec-044eefbde5ed	1fe23664-3168-4d02-a8f3-077cec07ea2f	0	10	t	8516cb93-1a73-404e-a86d-dcc4ab1bd54e	\N
05eafd37-8bee-4368-bcb4-6c7098531730	\N	registration-user-creation	962fdb71-b4bb-438b-80ec-044eefbde5ed	8516cb93-1a73-404e-a86d-dcc4ab1bd54e	0	20	f	\N	\N
87861133-586a-4a15-9efa-ca1f536546fa	\N	registration-password-action	962fdb71-b4bb-438b-80ec-044eefbde5ed	8516cb93-1a73-404e-a86d-dcc4ab1bd54e	0	50	f	\N	\N
9b84b149-7abc-4244-8223-74778366d150	\N	registration-recaptcha-action	962fdb71-b4bb-438b-80ec-044eefbde5ed	8516cb93-1a73-404e-a86d-dcc4ab1bd54e	3	60	f	\N	\N
451b521b-5279-4870-a7bf-9108c7aa264e	\N	registration-terms-and-conditions	962fdb71-b4bb-438b-80ec-044eefbde5ed	8516cb93-1a73-404e-a86d-dcc4ab1bd54e	3	70	f	\N	\N
fdecb4d1-dcfb-4dbe-9658-e9655d4497f2	\N	reset-credentials-choose-user	962fdb71-b4bb-438b-80ec-044eefbde5ed	e2603dfe-535c-45b6-9c46-94bde1864957	0	10	f	\N	\N
0b81ebc2-48d3-42de-8951-b632c70f7732	\N	reset-credential-email	962fdb71-b4bb-438b-80ec-044eefbde5ed	e2603dfe-535c-45b6-9c46-94bde1864957	0	20	f	\N	\N
e2f45d9c-80df-43d3-905b-8f35c74cc160	\N	reset-password	962fdb71-b4bb-438b-80ec-044eefbde5ed	e2603dfe-535c-45b6-9c46-94bde1864957	0	30	f	\N	\N
b5afa554-9c31-4245-abda-cb3a74a8a83a	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	e2603dfe-535c-45b6-9c46-94bde1864957	1	40	t	258beabc-5949-4670-946f-650eb3acb225	\N
011c4aec-be77-4755-b0e3-c7294b5c7d60	\N	conditional-user-configured	962fdb71-b4bb-438b-80ec-044eefbde5ed	258beabc-5949-4670-946f-650eb3acb225	0	10	f	\N	\N
258e4ecd-dfd4-4955-91d8-004df4ce4d02	\N	reset-otp	962fdb71-b4bb-438b-80ec-044eefbde5ed	258beabc-5949-4670-946f-650eb3acb225	0	20	f	\N	\N
ddf8c19a-c881-40c6-a81e-1ad4af6bae64	\N	client-secret	962fdb71-b4bb-438b-80ec-044eefbde5ed	e09d625d-49b5-4c40-9aa9-0f686349ba87	2	10	f	\N	\N
1c21118c-8999-42a7-bd8f-239b7bcd666b	\N	client-jwt	962fdb71-b4bb-438b-80ec-044eefbde5ed	e09d625d-49b5-4c40-9aa9-0f686349ba87	2	20	f	\N	\N
b7abc356-ea27-4aeb-bad8-6d08ce9d445a	\N	client-secret-jwt	962fdb71-b4bb-438b-80ec-044eefbde5ed	e09d625d-49b5-4c40-9aa9-0f686349ba87	2	30	f	\N	\N
f679af6c-e094-45be-96c7-8d4ff9254314	\N	client-x509	962fdb71-b4bb-438b-80ec-044eefbde5ed	e09d625d-49b5-4c40-9aa9-0f686349ba87	2	40	f	\N	\N
a0d97878-9980-48fb-9254-f99fa8eea9c3	\N	idp-review-profile	962fdb71-b4bb-438b-80ec-044eefbde5ed	00f43408-8dbc-4ed2-bd06-19e6d86cfabc	0	10	f	\N	b624e05e-659e-4c8e-b138-73bd209eb31c
83f93007-519c-411a-acda-dd6490033d2a	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	00f43408-8dbc-4ed2-bd06-19e6d86cfabc	0	20	t	685ce4f5-9ab2-4615-9806-e49b393d0b29	\N
97a7ac14-148c-4fb1-8dc7-d079b12602b3	\N	idp-create-user-if-unique	962fdb71-b4bb-438b-80ec-044eefbde5ed	685ce4f5-9ab2-4615-9806-e49b393d0b29	2	10	f	\N	c5ab2898-49ae-434b-b96d-97b2d9fda0fe
6c3f4ee5-96de-434d-be21-d47a8fd43ee2	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	685ce4f5-9ab2-4615-9806-e49b393d0b29	2	20	t	5077aba5-226f-44ad-9782-ccc09187bc53	\N
a34e23cb-0c5b-4261-9ddf-f8312cc4668a	\N	idp-confirm-link	962fdb71-b4bb-438b-80ec-044eefbde5ed	5077aba5-226f-44ad-9782-ccc09187bc53	0	10	f	\N	\N
fb1e20b6-d681-41d3-a78b-a3ab67aa3658	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	5077aba5-226f-44ad-9782-ccc09187bc53	0	20	t	ae1d6c73-20f6-4a40-a40a-9c2989e88bdf	\N
61c3c227-22a7-4c47-ada4-e18da8987698	\N	idp-email-verification	962fdb71-b4bb-438b-80ec-044eefbde5ed	ae1d6c73-20f6-4a40-a40a-9c2989e88bdf	2	10	f	\N	\N
397527f4-3809-4652-ac04-b3c25b9a8a41	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	ae1d6c73-20f6-4a40-a40a-9c2989e88bdf	2	20	t	e9e5b305-ddff-4aa1-8884-0cf66ada45f3	\N
353d9151-379a-4521-9148-840f2511b9b7	\N	idp-username-password-form	962fdb71-b4bb-438b-80ec-044eefbde5ed	e9e5b305-ddff-4aa1-8884-0cf66ada45f3	0	10	f	\N	\N
10b7ea75-13c0-46fa-bde7-bf46b59ce070	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	e9e5b305-ddff-4aa1-8884-0cf66ada45f3	1	20	t	8b09d53e-eb93-4227-acc2-3786714bfebf	\N
5497d1c8-9f7b-439b-ab2a-8b98472d415e	\N	conditional-user-configured	962fdb71-b4bb-438b-80ec-044eefbde5ed	8b09d53e-eb93-4227-acc2-3786714bfebf	0	10	f	\N	\N
24e0a624-e33f-4bd0-b9f9-3370c41f7ae4	\N	auth-otp-form	962fdb71-b4bb-438b-80ec-044eefbde5ed	8b09d53e-eb93-4227-acc2-3786714bfebf	0	20	f	\N	\N
b23f0629-e444-490c-ac33-5f1e6d94720f	\N	http-basic-authenticator	962fdb71-b4bb-438b-80ec-044eefbde5ed	2e66d1d7-08dd-46f8-b552-6519a1855e92	0	10	f	\N	\N
ac0a9475-0260-4533-99d6-b9bc8d720cdc	\N	docker-http-basic-authenticator	962fdb71-b4bb-438b-80ec-044eefbde5ed	713d8a40-1850-4df9-b40a-7cab06a3c183	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
f532034b-33f6-4990-902f-0ab96143fd4b	browser	browser based authentication	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	t	t
c415bfdc-43dc-4115-8e72-d8f49f1f0ea1	forms	Username, password, otp and other auth forms.	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	f	t
e8ffcedd-2934-46d0-83cb-d1d706720ef5	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	f	t
9102a116-9395-4461-a523-1635819d3d5e	direct grant	OpenID Connect Resource Owner Grant	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	t	t
9de04031-d636-4647-a7fc-65077651b11a	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	f	t
1fe23664-3168-4d02-a8f3-077cec07ea2f	registration	registration flow	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	t	t
8516cb93-1a73-404e-a86d-dcc4ab1bd54e	registration form	registration form	962fdb71-b4bb-438b-80ec-044eefbde5ed	form-flow	f	t
e2603dfe-535c-45b6-9c46-94bde1864957	reset credentials	Reset credentials for a user if they forgot their password or something	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	t	t
258beabc-5949-4670-946f-650eb3acb225	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	f	t
e09d625d-49b5-4c40-9aa9-0f686349ba87	clients	Base authentication for clients	962fdb71-b4bb-438b-80ec-044eefbde5ed	client-flow	t	t
00f43408-8dbc-4ed2-bd06-19e6d86cfabc	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	t	t
685ce4f5-9ab2-4615-9806-e49b393d0b29	User creation or linking	Flow for the existing/non-existing user alternatives	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	f	t
5077aba5-226f-44ad-9782-ccc09187bc53	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	f	t
ae1d6c73-20f6-4a40-a40a-9c2989e88bdf	Account verification options	Method with which to verity the existing account	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	f	t
e9e5b305-ddff-4aa1-8884-0cf66ada45f3	Verify Existing Account by Re-authentication	Reauthentication of existing account	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	f	t
8b09d53e-eb93-4227-acc2-3786714bfebf	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	f	t
2e66d1d7-08dd-46f8-b552-6519a1855e92	saml ecp	SAML ECP Profile Authentication Flow	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	t	t
713d8a40-1850-4df9-b40a-7cab06a3c183	docker auth	Used by Docker clients to authenticate against the IDP	962fdb71-b4bb-438b-80ec-044eefbde5ed	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
b624e05e-659e-4c8e-b138-73bd209eb31c	review profile config	962fdb71-b4bb-438b-80ec-044eefbde5ed
c5ab2898-49ae-434b-b96d-97b2d9fda0fe	create unique user config	962fdb71-b4bb-438b-80ec-044eefbde5ed
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
b624e05e-659e-4c8e-b138-73bd209eb31c	missing	update.profile.on.first.login
c5ab2898-49ae-434b-b96d-97b2d9fda0fe	false	require.password.update.after.registration
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
b48b1bb4-1735-462a-95b3-ffd0f907068f	t	f	master-realm	0	f	\N	\N	t	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
294ab06e-9ea6-48c3-8166-59b00af63675	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	t	f	broker	0	f	\N	\N	t	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
e1eabf61-45a2-4b63-936d-d1ce68866ada	t	f	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	t	f	admin-cli	0	t	\N	\N	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
c758c45c-a01d-4800-b5d2-dfde4a30a492	t	t	gaian	0	f	hsFJsxR0wP3Y7KXlfyXX3ggZHJ4Zr7BV		f		f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	-1	t	f	gaian	t	client-secret		gaian	\N	t	f	t	f
009f96bb-01ae-4ec5-93b5-88853bc82364	t	t	A7zhWp22zl@gatestautomation.com	0	f	r9V0xfcb0VbOP9sTGaTBOO30SrLXFUoJ	\N	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	-1	f	f	jhjla	t	client-secret	\N	A7zhWp22zl@gatestautomation.com	\N	t	f	t	f
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	t	t	HOLACRACY	0	f	GfUszmbtEEeFKE4lZ0DcbO0o2x5j5GPK	\N	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	-1	f	f	HOLACRACY	t	client-secret	\N	HOLACRACY	\N	t	f	t	f
5c13758d-f499-47ee-94cf-c97563dcb644	t	t	V26rJOFVK7@gatestautomation.com	0	f	chCUJhXY89bQNCH2YM7sUG3MVXcujnef	\N	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	-1	f	f	lkfjj	t	client-secret	\N	V26rJOFVK7@gatestautomation.com	\N	t	f	t	f
352ef396-c83f-4ed8-8c47-23cc928864aa	t	t	kvRSHS1BYy@gatestautomation.com	0	f	w5LFD55fDrkchUZYUHrhGbeXfpYQKFPI	\N	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	-1	f	f	mllmi	t	client-secret	\N	kvRSHS1BYy@gatestautomation.com	\N	t	f	t	f
2c111030-ed95-40ff-9976-12c8cd399083	t	t	UHKNLL9ZZU@gatestautomation.com	0	f	Ea5wJWBUnoGvndRXxkMUNi0xUTvyIAF4	\N	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	-1	f	f	bbemk	t	client-secret	\N	UHKNLL9ZZU@gatestautomation.com	\N	t	f	t	f
4d0ebf75-767a-4542-bbbe-7910f9096a7d	t	t	VoBjonLuQe@gatestautomation.com	0	f	ueDENa4iLmJMGjXBPuTpFTy2LNFgfHhD	\N	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	-1	f	f	dgjjh	t	client-secret	\N	VoBjonLuQe@gatestautomation.com	\N	t	f	t	f
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	t	t	l1jgLt50hJ@gatestautomation.com	0	f	TRMeTE7rIaeGkDSh2jEYXoz9IalIrZyt	\N	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	-1	f	f	fkdkj	t	client-secret	\N	l1jgLt50hJ@gatestautomation.com	\N	t	f	t	f
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	t	t	48mYRsIOdx@gatestautomation.com	0	f	8PlU1IHan9xL334LiQvkivAYCBZdd8xJ	\N	f	\N	f	962fdb71-b4bb-438b-80ec-044eefbde5ed	openid-connect	-1	f	f	hmeid	t	client-secret	\N	48mYRsIOdx@gatestautomation.com	\N	t	f	t	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
294ab06e-9ea6-48c3-8166-59b00af63675	post.logout.redirect.uris	+
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	post.logout.redirect.uris	+
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	pkce.code.challenge.method	S256
e1eabf61-45a2-4b63-936d-d1ce68866ada	post.logout.redirect.uris	+
e1eabf61-45a2-4b63-936d-d1ce68866ada	pkce.code.challenge.method	S256
c758c45c-a01d-4800-b5d2-dfde4a30a492	client.secret.creation.time	1715667331
c758c45c-a01d-4800-b5d2-dfde4a30a492	oauth2.device.authorization.grant.enabled	false
c758c45c-a01d-4800-b5d2-dfde4a30a492	oidc.ciba.grant.enabled	false
c758c45c-a01d-4800-b5d2-dfde4a30a492	backchannel.logout.session.required	true
c758c45c-a01d-4800-b5d2-dfde4a30a492	backchannel.logout.revoke.offline.tokens	false
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	client.secret.creation.time	1715667921
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	tenantId	c455ccc5-4775-4e93-94a9-7a7f930c8130
352ef396-c83f-4ed8-8c47-23cc928864aa	client.secret.creation.time	1715672999
352ef396-c83f-4ed8-8c47-23cc928864aa	tenantId	c455ccc5-4775-4e93-94a9-7a7f930c8130
2c111030-ed95-40ff-9976-12c8cd399083	client.secret.creation.time	1715677454
2c111030-ed95-40ff-9976-12c8cd399083	tenantId	c455ccc5-4775-4e93-94a9-7a7f930c8130
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	client.secret.creation.time	1715677559
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	tenantId	c455ccc5-4775-4e93-94a9-7a7f930c8130
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	client.secret.creation.time	1715677757
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	tenantId	c455ccc5-4775-4e93-94a9-7a7f930c8130
009f96bb-01ae-4ec5-93b5-88853bc82364	client.secret.creation.time	1715677945
009f96bb-01ae-4ec5-93b5-88853bc82364	tenantId	c455ccc5-4775-4e93-94a9-7a7f930c8130
5c13758d-f499-47ee-94cf-c97563dcb644	client.secret.creation.time	1715678077
5c13758d-f499-47ee-94cf-c97563dcb644	tenantId	c455ccc5-4775-4e93-94a9-7a7f930c8130
4d0ebf75-767a-4542-bbbe-7910f9096a7d	client.secret.creation.time	1715678117
4d0ebf75-767a-4542-bbbe-7910f9096a7d	tenantId	c455ccc5-4775-4e93-94a9-7a7f930c8130
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
ab7dbad7-62e1-4e95-91b0-607746b9c05c	offline_access	962fdb71-b4bb-438b-80ec-044eefbde5ed	OpenID Connect built-in scope: offline_access	openid-connect
5d166388-f1c1-4d92-a126-67dd72f95f06	role_list	962fdb71-b4bb-438b-80ec-044eefbde5ed	SAML role list	saml
266b0a2d-c5b3-48da-8009-10e1d50355a8	profile	962fdb71-b4bb-438b-80ec-044eefbde5ed	OpenID Connect built-in scope: profile	openid-connect
55a0393a-5a32-498b-ab88-270bc2f5a150	email	962fdb71-b4bb-438b-80ec-044eefbde5ed	OpenID Connect built-in scope: email	openid-connect
802997ab-56a5-437c-94aa-6463ff9c9213	address	962fdb71-b4bb-438b-80ec-044eefbde5ed	OpenID Connect built-in scope: address	openid-connect
2dbf10c9-a964-44ec-916b-ca5a590155e6	phone	962fdb71-b4bb-438b-80ec-044eefbde5ed	OpenID Connect built-in scope: phone	openid-connect
b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	roles	962fdb71-b4bb-438b-80ec-044eefbde5ed	OpenID Connect scope for add user roles to the access token	openid-connect
34569064-f04c-44fb-8c1c-bad44d91785a	web-origins	962fdb71-b4bb-438b-80ec-044eefbde5ed	OpenID Connect scope for add allowed web origins to the access token	openid-connect
286700a8-8570-44b0-b677-87b5376bd900	microprofile-jwt	962fdb71-b4bb-438b-80ec-044eefbde5ed	Microprofile - JWT built-in scope	openid-connect
c97b85ed-40c1-4353-a8bb-7f82c93510fc	acr	962fdb71-b4bb-438b-80ec-044eefbde5ed	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
ab7dbad7-62e1-4e95-91b0-607746b9c05c	true	display.on.consent.screen
ab7dbad7-62e1-4e95-91b0-607746b9c05c	${offlineAccessScopeConsentText}	consent.screen.text
5d166388-f1c1-4d92-a126-67dd72f95f06	true	display.on.consent.screen
5d166388-f1c1-4d92-a126-67dd72f95f06	${samlRoleListScopeConsentText}	consent.screen.text
266b0a2d-c5b3-48da-8009-10e1d50355a8	true	display.on.consent.screen
266b0a2d-c5b3-48da-8009-10e1d50355a8	${profileScopeConsentText}	consent.screen.text
266b0a2d-c5b3-48da-8009-10e1d50355a8	true	include.in.token.scope
55a0393a-5a32-498b-ab88-270bc2f5a150	true	display.on.consent.screen
55a0393a-5a32-498b-ab88-270bc2f5a150	${emailScopeConsentText}	consent.screen.text
55a0393a-5a32-498b-ab88-270bc2f5a150	true	include.in.token.scope
802997ab-56a5-437c-94aa-6463ff9c9213	true	display.on.consent.screen
802997ab-56a5-437c-94aa-6463ff9c9213	${addressScopeConsentText}	consent.screen.text
802997ab-56a5-437c-94aa-6463ff9c9213	true	include.in.token.scope
2dbf10c9-a964-44ec-916b-ca5a590155e6	true	display.on.consent.screen
2dbf10c9-a964-44ec-916b-ca5a590155e6	${phoneScopeConsentText}	consent.screen.text
2dbf10c9-a964-44ec-916b-ca5a590155e6	true	include.in.token.scope
b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	true	display.on.consent.screen
b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	${rolesScopeConsentText}	consent.screen.text
b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	false	include.in.token.scope
34569064-f04c-44fb-8c1c-bad44d91785a	false	display.on.consent.screen
34569064-f04c-44fb-8c1c-bad44d91785a		consent.screen.text
34569064-f04c-44fb-8c1c-bad44d91785a	false	include.in.token.scope
286700a8-8570-44b0-b677-87b5376bd900	false	display.on.consent.screen
286700a8-8570-44b0-b677-87b5376bd900	true	include.in.token.scope
c97b85ed-40c1-4353-a8bb-7f82c93510fc	false	display.on.consent.screen
c97b85ed-40c1-4353-a8bb-7f82c93510fc	false	include.in.token.scope
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
294ab06e-9ea6-48c3-8166-59b00af63675	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
294ab06e-9ea6-48c3-8166-59b00af63675	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
294ab06e-9ea6-48c3-8166-59b00af63675	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
294ab06e-9ea6-48c3-8166-59b00af63675	55a0393a-5a32-498b-ab88-270bc2f5a150	t
294ab06e-9ea6-48c3-8166-59b00af63675	34569064-f04c-44fb-8c1c-bad44d91785a	t
294ab06e-9ea6-48c3-8166-59b00af63675	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
294ab06e-9ea6-48c3-8166-59b00af63675	286700a8-8570-44b0-b677-87b5376bd900	f
294ab06e-9ea6-48c3-8166-59b00af63675	802997ab-56a5-437c-94aa-6463ff9c9213	f
294ab06e-9ea6-48c3-8166-59b00af63675	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	55a0393a-5a32-498b-ab88-270bc2f5a150	t
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	34569064-f04c-44fb-8c1c-bad44d91785a	t
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	286700a8-8570-44b0-b677-87b5376bd900	f
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	802997ab-56a5-437c-94aa-6463ff9c9213	f
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	55a0393a-5a32-498b-ab88-270bc2f5a150	t
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	34569064-f04c-44fb-8c1c-bad44d91785a	t
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	286700a8-8570-44b0-b677-87b5376bd900	f
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	802997ab-56a5-437c-94aa-6463ff9c9213	f
d500d0fb-0e7d-4672-9ec3-7ab4563fcdf9	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	55a0393a-5a32-498b-ab88-270bc2f5a150	t
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	34569064-f04c-44fb-8c1c-bad44d91785a	t
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	286700a8-8570-44b0-b677-87b5376bd900	f
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	802997ab-56a5-437c-94aa-6463ff9c9213	f
0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
b48b1bb4-1735-462a-95b3-ffd0f907068f	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
b48b1bb4-1735-462a-95b3-ffd0f907068f	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
b48b1bb4-1735-462a-95b3-ffd0f907068f	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
b48b1bb4-1735-462a-95b3-ffd0f907068f	55a0393a-5a32-498b-ab88-270bc2f5a150	t
b48b1bb4-1735-462a-95b3-ffd0f907068f	34569064-f04c-44fb-8c1c-bad44d91785a	t
b48b1bb4-1735-462a-95b3-ffd0f907068f	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
b48b1bb4-1735-462a-95b3-ffd0f907068f	286700a8-8570-44b0-b677-87b5376bd900	f
b48b1bb4-1735-462a-95b3-ffd0f907068f	802997ab-56a5-437c-94aa-6463ff9c9213	f
b48b1bb4-1735-462a-95b3-ffd0f907068f	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
e1eabf61-45a2-4b63-936d-d1ce68866ada	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
e1eabf61-45a2-4b63-936d-d1ce68866ada	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
e1eabf61-45a2-4b63-936d-d1ce68866ada	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
e1eabf61-45a2-4b63-936d-d1ce68866ada	55a0393a-5a32-498b-ab88-270bc2f5a150	t
e1eabf61-45a2-4b63-936d-d1ce68866ada	34569064-f04c-44fb-8c1c-bad44d91785a	t
e1eabf61-45a2-4b63-936d-d1ce68866ada	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
e1eabf61-45a2-4b63-936d-d1ce68866ada	286700a8-8570-44b0-b677-87b5376bd900	f
e1eabf61-45a2-4b63-936d-d1ce68866ada	802997ab-56a5-437c-94aa-6463ff9c9213	f
e1eabf61-45a2-4b63-936d-d1ce68866ada	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
c758c45c-a01d-4800-b5d2-dfde4a30a492	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
c758c45c-a01d-4800-b5d2-dfde4a30a492	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
c758c45c-a01d-4800-b5d2-dfde4a30a492	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
c758c45c-a01d-4800-b5d2-dfde4a30a492	55a0393a-5a32-498b-ab88-270bc2f5a150	t
c758c45c-a01d-4800-b5d2-dfde4a30a492	34569064-f04c-44fb-8c1c-bad44d91785a	t
c758c45c-a01d-4800-b5d2-dfde4a30a492	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
c758c45c-a01d-4800-b5d2-dfde4a30a492	286700a8-8570-44b0-b677-87b5376bd900	f
c758c45c-a01d-4800-b5d2-dfde4a30a492	802997ab-56a5-437c-94aa-6463ff9c9213	f
c758c45c-a01d-4800-b5d2-dfde4a30a492	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	55a0393a-5a32-498b-ab88-270bc2f5a150	t
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	34569064-f04c-44fb-8c1c-bad44d91785a	t
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	286700a8-8570-44b0-b677-87b5376bd900	f
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	802997ab-56a5-437c-94aa-6463ff9c9213	f
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
352ef396-c83f-4ed8-8c47-23cc928864aa	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
352ef396-c83f-4ed8-8c47-23cc928864aa	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
352ef396-c83f-4ed8-8c47-23cc928864aa	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
352ef396-c83f-4ed8-8c47-23cc928864aa	55a0393a-5a32-498b-ab88-270bc2f5a150	t
352ef396-c83f-4ed8-8c47-23cc928864aa	34569064-f04c-44fb-8c1c-bad44d91785a	t
352ef396-c83f-4ed8-8c47-23cc928864aa	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
352ef396-c83f-4ed8-8c47-23cc928864aa	286700a8-8570-44b0-b677-87b5376bd900	f
352ef396-c83f-4ed8-8c47-23cc928864aa	802997ab-56a5-437c-94aa-6463ff9c9213	f
352ef396-c83f-4ed8-8c47-23cc928864aa	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
2c111030-ed95-40ff-9976-12c8cd399083	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
2c111030-ed95-40ff-9976-12c8cd399083	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
2c111030-ed95-40ff-9976-12c8cd399083	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
2c111030-ed95-40ff-9976-12c8cd399083	55a0393a-5a32-498b-ab88-270bc2f5a150	t
2c111030-ed95-40ff-9976-12c8cd399083	34569064-f04c-44fb-8c1c-bad44d91785a	t
2c111030-ed95-40ff-9976-12c8cd399083	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
2c111030-ed95-40ff-9976-12c8cd399083	286700a8-8570-44b0-b677-87b5376bd900	f
2c111030-ed95-40ff-9976-12c8cd399083	802997ab-56a5-437c-94aa-6463ff9c9213	f
2c111030-ed95-40ff-9976-12c8cd399083	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	55a0393a-5a32-498b-ab88-270bc2f5a150	t
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	34569064-f04c-44fb-8c1c-bad44d91785a	t
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	286700a8-8570-44b0-b677-87b5376bd900	f
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	802997ab-56a5-437c-94aa-6463ff9c9213	f
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	55a0393a-5a32-498b-ab88-270bc2f5a150	t
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	34569064-f04c-44fb-8c1c-bad44d91785a	t
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	286700a8-8570-44b0-b677-87b5376bd900	f
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	802997ab-56a5-437c-94aa-6463ff9c9213	f
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
009f96bb-01ae-4ec5-93b5-88853bc82364	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
009f96bb-01ae-4ec5-93b5-88853bc82364	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
009f96bb-01ae-4ec5-93b5-88853bc82364	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
009f96bb-01ae-4ec5-93b5-88853bc82364	55a0393a-5a32-498b-ab88-270bc2f5a150	t
009f96bb-01ae-4ec5-93b5-88853bc82364	34569064-f04c-44fb-8c1c-bad44d91785a	t
009f96bb-01ae-4ec5-93b5-88853bc82364	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
009f96bb-01ae-4ec5-93b5-88853bc82364	286700a8-8570-44b0-b677-87b5376bd900	f
009f96bb-01ae-4ec5-93b5-88853bc82364	802997ab-56a5-437c-94aa-6463ff9c9213	f
009f96bb-01ae-4ec5-93b5-88853bc82364	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
5c13758d-f499-47ee-94cf-c97563dcb644	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
5c13758d-f499-47ee-94cf-c97563dcb644	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
5c13758d-f499-47ee-94cf-c97563dcb644	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
5c13758d-f499-47ee-94cf-c97563dcb644	55a0393a-5a32-498b-ab88-270bc2f5a150	t
5c13758d-f499-47ee-94cf-c97563dcb644	34569064-f04c-44fb-8c1c-bad44d91785a	t
5c13758d-f499-47ee-94cf-c97563dcb644	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
5c13758d-f499-47ee-94cf-c97563dcb644	286700a8-8570-44b0-b677-87b5376bd900	f
5c13758d-f499-47ee-94cf-c97563dcb644	802997ab-56a5-437c-94aa-6463ff9c9213	f
5c13758d-f499-47ee-94cf-c97563dcb644	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
4d0ebf75-767a-4542-bbbe-7910f9096a7d	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
4d0ebf75-767a-4542-bbbe-7910f9096a7d	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
4d0ebf75-767a-4542-bbbe-7910f9096a7d	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
4d0ebf75-767a-4542-bbbe-7910f9096a7d	55a0393a-5a32-498b-ab88-270bc2f5a150	t
4d0ebf75-767a-4542-bbbe-7910f9096a7d	34569064-f04c-44fb-8c1c-bad44d91785a	t
4d0ebf75-767a-4542-bbbe-7910f9096a7d	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
4d0ebf75-767a-4542-bbbe-7910f9096a7d	286700a8-8570-44b0-b677-87b5376bd900	f
4d0ebf75-767a-4542-bbbe-7910f9096a7d	802997ab-56a5-437c-94aa-6463ff9c9213	f
4d0ebf75-767a-4542-bbbe-7910f9096a7d	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
ab7dbad7-62e1-4e95-91b0-607746b9c05c	e21f7203-111b-4944-9b12-8a27c5d62b62
\.


--
-- Data for Name: client_session; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_session (id, client_id, redirect_uri, state, "timestamp", session_id, auth_method, realm_id, auth_user_id, current_action) FROM stdin;
\.


--
-- Data for Name: client_session_auth_status; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_session_auth_status (authenticator, status, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_note; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_prot_mapper; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_session_prot_mapper (protocol_mapper_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_session_role; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_session_role (role_id, client_session) FROM stdin;
\.


--
-- Data for Name: client_user_session_note; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.client_user_session_note (name, value, client_session) FROM stdin;
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
a1ff9895-f5af-496c-9ce2-809782a36231	Trusted Hosts	962fdb71-b4bb-438b-80ec-044eefbde5ed	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	anonymous
86a65678-6c9f-4394-a414-0411744e308c	Consent Required	962fdb71-b4bb-438b-80ec-044eefbde5ed	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	anonymous
b440d378-59bb-47ef-9d7c-cbdab95b0ac4	Full Scope Disabled	962fdb71-b4bb-438b-80ec-044eefbde5ed	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	anonymous
2d16a165-6b89-4310-9043-d56503231ddf	Max Clients Limit	962fdb71-b4bb-438b-80ec-044eefbde5ed	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	anonymous
3febe8e5-7786-4ed3-a0b2-f2c4384eca92	Allowed Protocol Mapper Types	962fdb71-b4bb-438b-80ec-044eefbde5ed	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	anonymous
021691b6-cd84-41f9-9b68-58d619cd02a5	Allowed Client Scopes	962fdb71-b4bb-438b-80ec-044eefbde5ed	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	anonymous
0abe404d-f89c-4111-aad3-d45162cbde76	Allowed Protocol Mapper Types	962fdb71-b4bb-438b-80ec-044eefbde5ed	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	authenticated
40d75291-f36f-44a1-b883-d31f728c6276	Allowed Client Scopes	962fdb71-b4bb-438b-80ec-044eefbde5ed	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	authenticated
f0fa7da6-44a0-412a-b501-d48007a6e5c8	rsa-generated	962fdb71-b4bb-438b-80ec-044eefbde5ed	rsa-generated	org.keycloak.keys.KeyProvider	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N
aba4a8ce-f731-4c6f-a53a-d00eaeb06e7d	rsa-enc-generated	962fdb71-b4bb-438b-80ec-044eefbde5ed	rsa-enc-generated	org.keycloak.keys.KeyProvider	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N
dfde2301-2b40-4f7b-b643-744290036e53	hmac-generated	962fdb71-b4bb-438b-80ec-044eefbde5ed	hmac-generated	org.keycloak.keys.KeyProvider	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N
869b18b4-f5f8-4aa2-afe2-1a6e3a5cd39c	aes-generated	962fdb71-b4bb-438b-80ec-044eefbde5ed	aes-generated	org.keycloak.keys.KeyProvider	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
c1e7b2bb-042d-4eae-b992-da0597c2e7c8	a1ff9895-f5af-496c-9ce2-809782a36231	client-uris-must-match	true
3c386692-5e30-4773-8a80-188bd97b5cb4	a1ff9895-f5af-496c-9ce2-809782a36231	host-sending-registration-request-must-match	true
fbf685ad-8e4b-4ca9-9207-2b68b4c3e812	021691b6-cd84-41f9-9b68-58d619cd02a5	allow-default-scopes	true
1cd4d511-afae-470c-a974-58bfac3bb628	40d75291-f36f-44a1-b883-d31f728c6276	allow-default-scopes	true
56a34ff5-8e8a-4f91-86b1-071142ed1b62	0abe404d-f89c-4111-aad3-d45162cbde76	allowed-protocol-mapper-types	saml-user-property-mapper
8009b44d-32d3-4b59-92da-d165f53a54a4	0abe404d-f89c-4111-aad3-d45162cbde76	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
c2316753-8364-47b8-9687-788473d30b38	0abe404d-f89c-4111-aad3-d45162cbde76	allowed-protocol-mapper-types	saml-user-attribute-mapper
2711dba7-ece8-424b-bd7f-ff2121ad2d98	0abe404d-f89c-4111-aad3-d45162cbde76	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
89e62e08-52f6-49bb-a92b-f056563d4ce5	0abe404d-f89c-4111-aad3-d45162cbde76	allowed-protocol-mapper-types	saml-role-list-mapper
60a21dde-9775-4dce-9247-5cefb2193cde	0abe404d-f89c-4111-aad3-d45162cbde76	allowed-protocol-mapper-types	oidc-full-name-mapper
0a8cdd85-9e84-44a7-ab74-55e2e05be7a7	0abe404d-f89c-4111-aad3-d45162cbde76	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
fbe5d63c-f3d9-4a78-ad52-0d89779962b2	0abe404d-f89c-4111-aad3-d45162cbde76	allowed-protocol-mapper-types	oidc-address-mapper
82ad4d83-11a8-463b-9d86-1d0e065f8345	2d16a165-6b89-4310-9043-d56503231ddf	max-clients	200
898f0842-67ec-4ba7-80e5-c6e98dc95419	3febe8e5-7786-4ed3-a0b2-f2c4384eca92	allowed-protocol-mapper-types	saml-user-attribute-mapper
fea45a0f-7e51-4356-84da-31615a84bbf6	3febe8e5-7786-4ed3-a0b2-f2c4384eca92	allowed-protocol-mapper-types	saml-user-property-mapper
ced458d1-4713-408a-8d4f-ab5e3b593e2e	3febe8e5-7786-4ed3-a0b2-f2c4384eca92	allowed-protocol-mapper-types	oidc-address-mapper
0972037b-5fad-451b-b7df-a0f773b9591e	3febe8e5-7786-4ed3-a0b2-f2c4384eca92	allowed-protocol-mapper-types	oidc-full-name-mapper
1492d212-976c-477e-b79f-e515acfca571	3febe8e5-7786-4ed3-a0b2-f2c4384eca92	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
e88aa5a8-0139-4fcd-94ad-c5bbe45dcb92	3febe8e5-7786-4ed3-a0b2-f2c4384eca92	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
215d6f9b-d492-4ffb-9d4d-0623a6578aee	3febe8e5-7786-4ed3-a0b2-f2c4384eca92	allowed-protocol-mapper-types	saml-role-list-mapper
b058558d-6697-47a0-97ed-55f821b4a6cb	3febe8e5-7786-4ed3-a0b2-f2c4384eca92	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
92317c90-2653-4201-9d0c-979277d6e616	869b18b4-f5f8-4aa2-afe2-1a6e3a5cd39c	secret	j_dtiWH9yM04Lq3nLmolEw
c616d0bc-fbb9-4c56-abaa-9aed0b29080a	869b18b4-f5f8-4aa2-afe2-1a6e3a5cd39c	kid	ca8267e3-f7d5-4383-99a7-8a1afa736ed1
7b2e3186-cb1e-4071-a310-613167b1d3c2	869b18b4-f5f8-4aa2-afe2-1a6e3a5cd39c	priority	100
59b69af2-2bca-4d58-a7a4-ce4f2ec1f8e4	f0fa7da6-44a0-412a-b501-d48007a6e5c8	keyUse	SIG
81bcc262-100c-4e6a-9143-db7152343cd3	f0fa7da6-44a0-412a-b501-d48007a6e5c8	privateKey	MIIEogIBAAKCAQEAruJrY+goKiamd2K0YQf/GkbI0y9fd5THtqMgYZnodnX0YwGkm36ArvpJ61IOKBTHRR0nVWXXZYJtmKjbOi3HPuZViDlWniEl0d9KbUX4OAsRk7Ud5ifRVI8/c98Ixnxqur3ETc40TBuKOzlIvWftAypQZjKsZGEX4JRyG/5l2Uho6osBnrV249RjDs/N8/B7jvxoMnvXqcao1hdkNnO7GxLo/3ljWqvhF0bq9uQMHlTUsTAzQOWpdSWUXrCAi/w4GIfUtAGEAV9lkbEmshwK+9Nb6UBNTTc/4Ui/7/P8ELZRsfl2qoo33FwErVXDqTGJCgijQ8ly54FiQRpJaX7iTQIDAQABAoIBACv3n7En8kUan3pfVeMZLBESn7W8cL9zJ7yqiV8QXym9IPptNNGk/bxAD6p6YDXCd5DQMg3dw0fxgRVCyo73aGLPbMyJQdYSllwLy73qO+v3GG2uuLwe4ZllRDog5idkqz6UrBA1md9Sgy+9iKSZxrQnhLwU3FOGN4cOOxv/muKDz/Yabv0QDCyUEMYlE4b/yfXlxBGa+mr0fv9tHfmh8NEFzyvBr8NyBwOIiH8APEPl4gXfekLjFE3wDlJklo95h05+C/t5i3KArZHmbq82WCahkuaqLBZ60BSoz3ovlLxMrfMwHCC2C8fUF0hPn4RgjsLqGC2SuFByzVag25pybG8CgYEA2CTY1AkWQY61pOmnrjQLAf4x3bIc4DkK1/TNp5RgxJliX+39fNGvD/HFyD/doFEgMPJ/nODg2ROyBa90gaiV16p6CJ1AVzuo0PYF08sZd+Z0+VcHuSJl4KVOh92JcZLUt61YetfTdDs1ckEKueKgvo7YR1V3vCDVHzFwubVA2esCgYEAzyHnVGWKjjwf6QxOo2VTHUNzao8NjwHwSzjG1Dr4UTi5fVoncIcEgDQ/o0MZC9Fl/L0K9zaZUPuDcq3qQzRo75sJXpbt0JDKkW3zZGcjRl5YA6Z1CcY7Jhyl71eMY+IpAdEjKmgaKAKSSE3PeQ27ogHMYg7LL6lIRm0Tw0h5rqcCgYBVX4h9h/FQh6vbrabbuha2/M55gMbDEgTkc/9fN85ZGTSwK3K6gKAjLh4vEHrbve93JfGd530ogQ0KDdl49TvqaZ22FVa6ngf6MZLvqwMuRsrhSaz1RU70QpcYNzr4r0RyIHgYXXNaL6DWtjYkYg2X9xgaZPncRyOnJIIf+CXbbQKBgEBaDy3IUlC4W02jNjdLfpQD5bLAePzqJEaqgBNlsspBLlfEj6ZFPF+8W90UNo7WYrIv5V1CyEVBrugNIk/403VFnJaXm5EFuvmNyGV0KaBuJTgVGh2MScogcmk2sPZDSGw5FozRRPcTPXFbQ08ftiCyIFaCtBu9oyfGMbKlLLDXAoGAaX9KN0lLqJkDm1hAk0B6iq7Mg9Wg5ZH2ZE48EslHUgwq2jAya/20fI9iToDzv12AV6/gzNWFxOFp7rVC6EnTWLtswKbkpX4viXYOxxRXj3Yal2MZU5IkM4RtOnASOFCVxz5krkM4IfgHlLm6bMn9rwpZYZ+q3K5IH/2YQSCYM6o=
00d45265-4b35-4b4f-bdd6-dc166d193ff6	f0fa7da6-44a0-412a-b501-d48007a6e5c8	certificate	MIICmzCCAYMCBgGPbRdiGjANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjQwNTEyMTM1NTAwWhcNMzQwNTEyMTM1NjQwWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCu4mtj6CgqJqZ3YrRhB/8aRsjTL193lMe2oyBhmeh2dfRjAaSbfoCu+knrUg4oFMdFHSdVZddlgm2YqNs6Lcc+5lWIOVaeISXR30ptRfg4CxGTtR3mJ9FUjz9z3wjGfGq6vcRNzjRMG4o7OUi9Z+0DKlBmMqxkYRfglHIb/mXZSGjqiwGetXbj1GMOz83z8HuO/Ggye9epxqjWF2Q2c7sbEuj/eWNaq+EXRur25AweVNSxMDNA5al1JZResICL/DgYh9S0AYQBX2WRsSayHAr701vpQE1NNz/hSL/v8/wQtlGx+XaqijfcXAStVcOpMYkKCKNDyXLngWJBGklpfuJNAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAA49Icgvjfe3APa1bKRTbUckVhN9QG1fAAuj/bxWa1GwQfbje0FnNn2ECQmRMloGX+XHw3jeioGpxJR97D7lq8ToEwadGiYy6Kry/mdAEU18grHsdk/bji1xzFsZyMwk+dwoR/WBgdTCs8hyAuENllOjMKbwYG72qth9t4FU2IFdOnPX+jIHKpyebPhgLg9xlYSTqmLqdB1H2ueKQbEc8Qh+FV408D58Dw+U0hXKiwbNj0naXrGI6w0ODhBY8En31tB+Yln+RxoWff2oCcUWyNLsbAGkYIdEP/YRlNhCvzU7gnOVsXGInHFCquqpiRi0mnWy3zoEd3hu5M+PHNKUSUs=
b76c8343-c596-434f-8559-ec7e7e254719	f0fa7da6-44a0-412a-b501-d48007a6e5c8	priority	100
e18eff7f-e071-4ed1-9a0e-552e0b0967a7	dfde2301-2b40-4f7b-b643-744290036e53	secret	_GXmyKVGDdwQ3ByvhXLpY7GUr-EAzVCL6cpxQ7-XBNC-KsNQZ2p_4-uvbEZViZf5LPHWcmlYwYq10O-6PckxLQ
e908a4dc-d053-4640-9fde-eb2bec203031	dfde2301-2b40-4f7b-b643-744290036e53	kid	d7a64667-ed35-41f4-911d-7c359df7908d
151fdd8d-ff68-45a4-bc85-bb774ac2789d	dfde2301-2b40-4f7b-b643-744290036e53	priority	100
5255d1c3-6ab9-467f-9015-3a43f02ec0d9	dfde2301-2b40-4f7b-b643-744290036e53	algorithm	HS256
5638ad63-c0e3-4b13-851c-9fa04173507a	aba4a8ce-f731-4c6f-a53a-d00eaeb06e7d	priority	100
bb10fa4b-ed18-4eb9-a5bc-3ea4961d3560	aba4a8ce-f731-4c6f-a53a-d00eaeb06e7d	keyUse	ENC
81ff90c3-51cd-448a-8329-dd79cabe94c7	aba4a8ce-f731-4c6f-a53a-d00eaeb06e7d	privateKey	MIIEowIBAAKCAQEAyYq6oQNNDsBwA7AVf4eiDjAK6aW+0teUsh157w2l5+kP6QtmtASYmXYDQJrG2Fg6jOpW1HdhWmuYq36iL3je9YzqntScanXiqTXaXj9wLRcSOaIKrBfoMoAJMG6Q5T2XInKttlYV+PG1LBokBd647/87bvslEEfZ9ob71xziME4ruelW0gK/tE09yneiSZyCmhm4xmGkLGnGY0Ul0NIE10rElX/F0EIQdckUcKXnI61WtG7cQdwORBfjXwoWwQlhg4r0gSKyG1sLWZIXbMTRz7Oyl2ncTrVFQkVfon8iUfbq6ty19YCZW10r3lU3bJgH1D67PlZuLDnUwgBfLjsr9wIDAQABAoIBABgSBg0h5aD2kcpBoaesDXTv/vWocnx1ppAz811TfiDkVclJr81IjpMmzueh31AfuspxWHJ4BDwLhV3XZMu8/gqfTGGGLLI4Ucb6JBJFNa1k8oEd8x6vnO9JxGSGPVmWUV0aC4OEj4uTuUVtpSdq/MpzwLzrU3djesrglJER+t+1gqBq48EHi3XfLh/ipZbDZxIV7t8IoIA7IWymFYA/s2OkK7MoB7kwRQ5S1jC5VtQRwex+6PDyjfGRUILGonH6A4qaaMLxK7AazHy2BbEaFOmtyAeeny9BvVaChvJUAGev1TXHeXV8kAyr8cbD3ykHC76qD1LmdUgy76lZ/91Xrw0CgYEA887fxysjwMmDLVoPRgZulquGdfcapNIc1e7LhQq+hWSH5K9uSEZOM487ppc7/IYuP2wNkR4uUWcLBmukFmQESP8jJnOq8pl7Xp2l1GAB193buNUqWn37bCiUtznJM3Gt/KCprz+Vv7xnywKgNWlBMWrN48xLLWFvEW64hFWUoDMCgYEA057ICIb0vZPZv0Uji+s7SwsJCfHkUg5XMth/P6guYjPuDXFefbj2jZ3jKd3a/KaD5MJVANtAArtPdkmJlDchckQHlMAD6zofEAUkSp9xGEsZXDV5UolV3GJ43J/YRHUpugViUU9oo3N92/bnOGsWtRUaMPhfI7oqHNxyZ4+J8S0CgYA/yS3us7Ck7ZOuN9OrJF+md7W0AzQrTvVQWytP4WG7EHQlNmiJ7CrlfmHC0epVxN0wpppeDyFbFrRht6O0X/JnDqkplDVzRwhp1qDeEUgqK9ciYlK0XiV7RJqz3SBwnxs/7uC2AtKw2R/mkwdLMgBmZ2T6ZiZ89vLSAr+vj5xU1QKBgEC4H78T3weXjxGDCJMDFvglYNdMxiIeRqbDNW93dPANp7EuydIzXhwDfHTSZ+W62z17/VkstI/hTzUC2nOcxLrYeWURsGEhPly85dN4nbLrTM85f2gxnjOvXf1DWXXeSyub9+ycF4ldidFa2m4TujcZRBBT9WzMw5JeDRMFAA/lAoGBAMKueAOrmt2PZad7zyuH/RuBQzuu5Y5k/RnYj9GuSklvkS6xAjx1SEXQ2VMT0D8cdLC1g0o4JcNz12bsz8oSZNq3J027+/ubmYFnFilUYJVkwBSvIgCAHr2gLn9i6gBZa88LXa0+hkf09u56dqABuPPuGiXF1AybWAWHgZ4Rqgdf
6411af7d-0430-4676-81f9-dd23095e5421	aba4a8ce-f731-4c6f-a53a-d00eaeb06e7d	certificate	MIICmzCCAYMCBgGPbRdjazANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjQwNTEyMTM1NTAwWhcNMzQwNTEyMTM1NjQwWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDJirqhA00OwHADsBV/h6IOMArppb7S15SyHXnvDaXn6Q/pC2a0BJiZdgNAmsbYWDqM6lbUd2Faa5irfqIveN71jOqe1JxqdeKpNdpeP3AtFxI5ogqsF+gygAkwbpDlPZcicq22VhX48bUsGiQF3rjv/ztu+yUQR9n2hvvXHOIwTiu56VbSAr+0TT3Kd6JJnIKaGbjGYaQsacZjRSXQ0gTXSsSVf8XQQhB1yRRwpecjrVa0btxB3A5EF+NfChbBCWGDivSBIrIbWwtZkhdsxNHPs7KXadxOtUVCRV+ifyJR9urq3LX1gJlbXSveVTdsmAfUPrs+Vm4sOdTCAF8uOyv3AgMBAAEwDQYJKoZIhvcNAQELBQADggEBAHHehlmPYLm/g2omXIU5r4G1nQdb6B88dA6SKklilz4BQab+VxVy57pDG7EJAxiDDy1Ys3I/+mAQS4G+5VLF2qUg0THdaKjmwOH3f5d7eqjLHgLaeqddVzGHg9iUUWwgZplJTjgzD6odsT2HxG1h3GhTbx9ZbSi9F/NWZQgE1ggE9uaOC0GVK6SVcCxTsUG6Cg2DcSC3RoKymzBa6QHP6fO6BOUO2AopfDHjW3kznEd/4KB/jdpfFdZ0t2yv3ZwNUYqLKQzKeTAs76VHA4zMTrVqSzgo+d38pVEzCp0dmCp8bie7fTxPXXv3MRQwy3eXVCI7JoranUyku9hWPLHGwlw=
97897202-c244-4239-89b4-d66647a52e3a	aba4a8ce-f731-4c6f-a53a-d00eaeb06e7d	algorithm	RSA-OAEP
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.composite_role (composite, child_role) FROM stdin;
a53bb093-34f1-4b39-b476-988513f41669	b3097298-292b-4640-9a78-4fe80f96b4e4
a53bb093-34f1-4b39-b476-988513f41669	eb237a7c-a9bd-479c-a366-cd38fc95d517
a53bb093-34f1-4b39-b476-988513f41669	de86a0cb-b992-46b6-946f-7fcfc749f809
a53bb093-34f1-4b39-b476-988513f41669	1ad417dd-3526-4d2a-a913-01122535826c
a53bb093-34f1-4b39-b476-988513f41669	a4446929-cef0-4ca9-a696-77dc813f3032
a53bb093-34f1-4b39-b476-988513f41669	9af40611-fd75-44bd-8924-777da0f778bd
a53bb093-34f1-4b39-b476-988513f41669	fc44b785-300a-4c83-9cb3-853fe6ecc86e
a53bb093-34f1-4b39-b476-988513f41669	fae91039-60ee-4f33-addd-a448ca3f6c80
a53bb093-34f1-4b39-b476-988513f41669	cc5cd6d7-efc9-41e0-8954-a651101c459c
a53bb093-34f1-4b39-b476-988513f41669	264bbe1f-a11f-4cb5-83c9-338fa900d220
a53bb093-34f1-4b39-b476-988513f41669	44b52c9d-df3d-4f0e-8a4c-d3e2fd982869
a53bb093-34f1-4b39-b476-988513f41669	64b10bd1-205d-4b21-9417-53440ed1e548
a53bb093-34f1-4b39-b476-988513f41669	b4abe05c-bee9-4c38-a1c1-94cd5fa01f19
a53bb093-34f1-4b39-b476-988513f41669	55cc23ad-4d8d-418a-bf04-dbb3ec11cfff
a53bb093-34f1-4b39-b476-988513f41669	6230393a-f464-43ee-83d0-9043d56e5bcb
a53bb093-34f1-4b39-b476-988513f41669	e0800b7e-0424-42dc-b7c9-40ad74f586cd
a53bb093-34f1-4b39-b476-988513f41669	1fb5a3d0-a1d8-479e-a8c6-55ab9866178b
a53bb093-34f1-4b39-b476-988513f41669	7d201047-5ced-42d4-85fc-6c79da044b0f
1ad417dd-3526-4d2a-a913-01122535826c	6230393a-f464-43ee-83d0-9043d56e5bcb
1ad417dd-3526-4d2a-a913-01122535826c	7d201047-5ced-42d4-85fc-6c79da044b0f
750bcd16-aced-4fce-bd44-1d0433981651	47692916-0d03-49da-814a-73e69b02688c
a4446929-cef0-4ca9-a696-77dc813f3032	e0800b7e-0424-42dc-b7c9-40ad74f586cd
750bcd16-aced-4fce-bd44-1d0433981651	147c66c3-511f-49c0-8552-d174b1dff0e5
147c66c3-511f-49c0-8552-d174b1dff0e5	844d9b28-ef3b-47cb-ac59-5a5b93b0e2d0
7f1152b6-4111-4584-b75a-6d989ed8f07d	adce559b-7430-4a3b-ab91-40196022a32b
a53bb093-34f1-4b39-b476-988513f41669	cc763a79-b99d-480f-8c36-67d9a19fb733
750bcd16-aced-4fce-bd44-1d0433981651	e21f7203-111b-4944-9b12-8a27c5d62b62
750bcd16-aced-4fce-bd44-1d0433981651	58eca589-9888-4c78-b0e7-4f485654ecb7
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
aad54ed4-4044-4edf-9074-f3939d16afeb	\N	password	882c94a4-7697-46d2-9a74-a9960f11ecda	1715522201130	\N	{"value":"pFlhuN49EbUZa/CQI3xl+ZqigKQzmVyA78Xam+l3U5M=","salt":"7vi6DrG4S4QpkbVINGyyag==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
e521137c-694b-4fd3-8757-dc44978059ff	\N	password	ad05207a-4c5b-4276-9bb3-1a6a23ded218	1715668389797	\N	{"value":"1xUYyJeULQ+4bcBWoqzM+Mv0NteQFxqowhDl/fMsoH4=","salt":"R4S6h4dTNiB9RpQ3xhoyMw==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
ecc2f676-b30c-4d77-a6bf-d2eaf7d93871	\N	password	a6907889-1c60-4e0f-9986-fc6fb6c4ff87	1715668624305	\N	{"value":"fmJUG9j306hcmCvYlBdneLkTK6liMDwxYFYBKKODbnk=","salt":"FIGyMEEXdqycPB98VX/+tg==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
ecce020b-94ff-41de-8f16-98391a510678	\N	password	04bbcce2-1e1f-474b-8249-4f1631bfcac9	1715668913182	\N	{"value":"5mu0edxHDO2WiZmwgp/0Yco+nZLO11vsVk+R+1GKhP0=","salt":"Kzhx0zN63Gpo6S5BUPtn1w==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
cd548a67-2070-4425-aa93-b34c5bfe9b00	\N	password	bb7dddf8-68f3-44d8-b52e-14c17a631ee1	1715669145336	\N	{"value":"DpWyIa7dolb1HOc+prhKcV5WCVKG96Mv6N2Djx3xmVY=","salt":"zSLmO6Ka5/eTLBFile9Tuw==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
725a318d-64e0-4624-b9f2-f26356d3f980	\N	password	c66b50c9-eb41-47ca-b9a9-290c1df4fea3	1715669646764	\N	{"value":"zN+MLVCFTgzJL18Bym55pB6DRlqPeCL29wPRwexjqcc=","salt":"XTQmiZCsKx63XaROpbBdSg==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
2a9887d5-2475-4d07-a632-7ac8c0410740	\N	password	8a088e82-6021-4bb3-b7e2-ff6f16583a94	1715673876129	\N	{"value":"n+9m4ZoQe87+3GeEOTMUnsfT6ST+F0c+A97uP/owGkA=","salt":"LNitRCnUf7mxeXSYWCj6Tw==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
0d7ccfed-f5b5-419b-b924-a80cd011d565	\N	password	2d637b27-36ca-4980-9f76-20b7d7aeb1cc	1715678076971	\N	{"value":"Bj255So7/DcI0jFqrQTwe9H6VBTN6H5vYwvSJmaH1Go=","salt":"xsSNB/L1iviGJcEA5dcUpw==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
20db867c-a3ee-4791-8b37-4e9bd410538c	\N	password	311ef274-ab20-4e81-8526-b4c5fa623d2f	1715677454492	\N	{"value":"A13wuEB1V/qXjE7n4uDG/QcutOHtQJPdYCMD1BXgvWM=","salt":"DqyhgKaVlHZ2JSCaFIowKg==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
a5178cd3-29e6-4590-9978-f2aea2734dd2	\N	password	6d984476-fbed-4c44-a3e1-a9004bfb6feb	1715677482944	\N	{"value":"hv4AKdDiSzu4Js+cvg9U0MdTmtNaViRUjuciiMi5hHQ=","salt":"gG2y9Qyy8Ms1oIex8Am7ow==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
71b7c927-5226-4d0d-b7d1-7b97143a4e0a	\N	password	50557830-c2d0-425f-8e35-59023f35a7b7	1715677559254	\N	{"value":"G0asoUOflEXeuPjROC/QwjuJpt9n5jA1MTJeqiwex+o=","salt":"jOSij/udc8vwmaiYyGTPSw==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
59a5a5de-d591-457e-bc69-42119c72dff7	\N	password	6e9d0fb9-2e33-40c2-ae9d-f710215a442e	1715672999526	\N	{"value":"qSTDH8/YAUxymI3sXFXvfmttU/ZxeBejLkUs3siiw44=","salt":"eY7lUKBHCxNnoaaxBsgCog==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
369eb0f7-0200-44f6-9348-ce1f973f8961	\N	password	05d532eb-ff53-4ff4-850c-ec26bf24bbf8	1715677756847	\N	{"value":"kt5TA3+W76s2exRufdRbiHCUlLPcqTHX876wK+5BPCo=","salt":"bitgdG0HceubE6ERC2lJQA==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
2195e597-50b8-445e-ad55-4d9703d80f4e	\N	password	e3e98db2-aa56-4580-b77e-942f801f1fb6	1715678117048	\N	{"value":"M4pluUm41UKwd6VHmxvftb9gLqpt5QdPsTm74Abatpo=","salt":"UWDvFaVJvYMRcMDSSMzFpw==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
705ccf66-134b-4504-8749-0e41ee6e1cf4	\N	password	f60a4d74-c389-4119-879f-0706f76da826	1715677945202	\N	{"value":"YXhpD5uaZ+w1Mfaodu41Y8Z8cMSZYu3eZa9CgySztBA=","salt":"QC8rBUBys+LBae8Y4XtkAA==","additionalParameters":{}}	{"hashIterations":27500,"algorithm":"pbkdf2-sha256","additionalParameters":{}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2024-05-12 13:56:32.748985	1	EXECUTED	9:6f1016664e21e16d26517a4418f5e3df	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.23.2	\N	\N	5522191348
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2024-05-12 13:56:32.829183	2	MARK_RAN	9:828775b1596a07d1200ba1d49e5e3941	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.23.2	\N	\N	5522191348
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2024-05-12 13:56:32.956982	3	EXECUTED	9:5f090e44a7d595883c1fb61f4b41fd38	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.23.2	\N	\N	5522191348
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2024-05-12 13:56:32.970393	4	EXECUTED	9:c07e577387a3d2c04d1adc9aaad8730e	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.23.2	\N	\N	5522191348
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2024-05-12 13:56:33.281769	5	EXECUTED	9:b68ce996c655922dbcd2fe6b6ae72686	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.23.2	\N	\N	5522191348
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2024-05-12 13:56:33.333717	6	MARK_RAN	9:543b5c9989f024fe35c6f6c5a97de88e	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.23.2	\N	\N	5522191348
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2024-05-12 13:56:33.577452	7	EXECUTED	9:765afebbe21cf5bbca048e632df38336	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.23.2	\N	\N	5522191348
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2024-05-12 13:56:33.618288	8	MARK_RAN	9:db4a145ba11a6fdaefb397f6dbf829a1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.23.2	\N	\N	5522191348
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2024-05-12 13:56:33.633874	9	EXECUTED	9:9d05c7be10cdb873f8bcb41bc3a8ab23	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.23.2	\N	\N	5522191348
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2024-05-12 13:56:33.908007	10	EXECUTED	9:18593702353128d53111f9b1ff0b82b8	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.23.2	\N	\N	5522191348
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2024-05-12 13:56:34.044784	11	EXECUTED	9:6122efe5f090e41a85c0f1c9e52cbb62	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.23.2	\N	\N	5522191348
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2024-05-12 13:56:34.063881	12	MARK_RAN	9:e1ff28bf7568451453f844c5d54bb0b5	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.23.2	\N	\N	5522191348
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2024-05-12 13:56:34.107585	13	EXECUTED	9:7af32cd8957fbc069f796b61217483fd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.23.2	\N	\N	5522191348
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2024-05-12 13:56:34.186716	14	EXECUTED	9:6005e15e84714cd83226bf7879f54190	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.23.2	\N	\N	5522191348
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2024-05-12 13:56:34.191609	15	MARK_RAN	9:bf656f5a2b055d07f314431cae76f06c	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.23.2	\N	\N	5522191348
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2024-05-12 13:56:34.198111	16	MARK_RAN	9:f8dadc9284440469dcf71e25ca6ab99b	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.23.2	\N	\N	5522191348
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2024-05-12 13:56:34.203866	17	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.23.2	\N	\N	5522191348
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2024-05-12 13:56:34.342553	18	EXECUTED	9:3368ff0be4c2855ee2dd9ca813b38d8e	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.23.2	\N	\N	5522191348
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2024-05-12 13:56:34.52905	19	EXECUTED	9:8ac2fb5dd030b24c0570a763ed75ed20	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.23.2	\N	\N	5522191348
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2024-05-12 13:56:34.544409	20	EXECUTED	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.23.2	\N	\N	5522191348
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2024-05-12 13:56:34.559817	21	MARK_RAN	9:831e82914316dc8a57dc09d755f23c51	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.23.2	\N	\N	5522191348
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2024-05-12 13:56:34.566843	22	MARK_RAN	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.23.2	\N	\N	5522191348
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2024-05-12 13:56:34.635949	23	EXECUTED	9:bc3d0f9e823a69dc21e23e94c7a94bb1	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.23.2	\N	\N	5522191348
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2024-05-12 13:56:34.647667	24	EXECUTED	9:c9999da42f543575ab790e76439a2679	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.23.2	\N	\N	5522191348
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2024-05-12 13:56:34.651637	25	MARK_RAN	9:0d6c65c6f58732d81569e77b10ba301d	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.23.2	\N	\N	5522191348
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2024-05-12 13:56:34.729233	26	EXECUTED	9:fc576660fc016ae53d2d4778d84d86d0	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.23.2	\N	\N	5522191348
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2024-05-12 13:56:34.945629	27	EXECUTED	9:43ed6b0da89ff77206289e87eaa9c024	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.23.2	\N	\N	5522191348
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2024-05-12 13:56:34.956949	28	EXECUTED	9:44bae577f551b3738740281eceb4ea70	update tableName=RESOURCE_SERVER_POLICY		\N	4.23.2	\N	\N	5522191348
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2024-05-12 13:56:35.193448	29	EXECUTED	9:bd88e1f833df0420b01e114533aee5e8	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.23.2	\N	\N	5522191348
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2024-05-12 13:56:35.242703	30	EXECUTED	9:a7022af5267f019d020edfe316ef4371	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.23.2	\N	\N	5522191348
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2024-05-12 13:56:35.285977	31	EXECUTED	9:fc155c394040654d6a79227e56f5e25a	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.23.2	\N	\N	5522191348
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2024-05-12 13:56:35.295209	32	EXECUTED	9:eac4ffb2a14795e5dc7b426063e54d88	customChange		\N	4.23.2	\N	\N	5522191348
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2024-05-12 13:56:35.307951	33	EXECUTED	9:54937c05672568c4c64fc9524c1e9462	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.23.2	\N	\N	5522191348
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2024-05-12 13:56:35.320537	34	MARK_RAN	9:3a32bace77c84d7678d035a7f5a8084e	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.23.2	\N	\N	5522191348
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2024-05-12 13:56:35.412119	35	EXECUTED	9:33d72168746f81f98ae3a1e8e0ca3554	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.23.2	\N	\N	5522191348
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2024-05-12 13:56:35.426782	36	EXECUTED	9:61b6d3d7a4c0e0024b0c839da283da0c	addColumn tableName=REALM		\N	4.23.2	\N	\N	5522191348
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2024-05-12 13:56:35.441629	37	EXECUTED	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.23.2	\N	\N	5522191348
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2024-05-12 13:56:35.45023	38	EXECUTED	9:a2b870802540cb3faa72098db5388af3	addColumn tableName=FED_USER_CONSENT		\N	4.23.2	\N	\N	5522191348
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2024-05-12 13:56:35.459166	39	EXECUTED	9:132a67499ba24bcc54fb5cbdcfe7e4c0	addColumn tableName=IDENTITY_PROVIDER		\N	4.23.2	\N	\N	5522191348
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2024-05-12 13:56:35.463226	40	MARK_RAN	9:938f894c032f5430f2b0fafb1a243462	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.23.2	\N	\N	5522191348
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2024-05-12 13:56:35.468996	41	MARK_RAN	9:845c332ff1874dc5d35974b0babf3006	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.23.2	\N	\N	5522191348
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2024-05-12 13:56:35.480798	42	EXECUTED	9:fc86359c079781adc577c5a217e4d04c	customChange		\N	4.23.2	\N	\N	5522191348
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2024-05-12 13:56:35.90311	43	EXECUTED	9:59a64800e3c0d09b825f8a3b444fa8f4	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.23.2	\N	\N	5522191348
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2024-05-12 13:56:35.915924	44	EXECUTED	9:d48d6da5c6ccf667807f633fe489ce88	addColumn tableName=USER_ENTITY		\N	4.23.2	\N	\N	5522191348
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-05-12 13:56:35.929143	45	EXECUTED	9:dde36f7973e80d71fceee683bc5d2951	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.23.2	\N	\N	5522191348
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-05-12 13:56:35.940655	46	EXECUTED	9:b855e9b0a406b34fa323235a0cf4f640	customChange		\N	4.23.2	\N	\N	5522191348
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-05-12 13:56:35.945027	47	MARK_RAN	9:51abbacd7b416c50c4421a8cabf7927e	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.23.2	\N	\N	5522191348
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-05-12 13:56:36.043012	48	EXECUTED	9:bdc99e567b3398bac83263d375aad143	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.23.2	\N	\N	5522191348
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2024-05-12 13:56:36.051409	49	EXECUTED	9:d198654156881c46bfba39abd7769e69	addColumn tableName=REALM		\N	4.23.2	\N	\N	5522191348
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2024-05-12 13:56:36.265133	50	EXECUTED	9:cfdd8736332ccdd72c5256ccb42335db	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.23.2	\N	\N	5522191348
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2024-05-12 13:56:36.377517	51	EXECUTED	9:7c84de3d9bd84d7f077607c1a4dcb714	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.23.2	\N	\N	5522191348
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2024-05-12 13:56:36.38978	52	EXECUTED	9:5a6bb36cbefb6a9d6928452c0852af2d	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	5522191348
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2024-05-12 13:56:36.397488	53	EXECUTED	9:8f23e334dbc59f82e0a328373ca6ced0	update tableName=REALM		\N	4.23.2	\N	\N	5522191348
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2024-05-12 13:56:36.404864	54	EXECUTED	9:9156214268f09d970cdf0e1564d866af	update tableName=CLIENT		\N	4.23.2	\N	\N	5522191348
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2024-05-12 13:56:36.423648	55	EXECUTED	9:db806613b1ed154826c02610b7dbdf74	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.23.2	\N	\N	5522191348
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2024-05-12 13:56:36.437792	56	EXECUTED	9:229a041fb72d5beac76bb94a5fa709de	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.23.2	\N	\N	5522191348
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2024-05-12 13:56:36.511396	57	EXECUTED	9:079899dade9c1e683f26b2aa9ca6ff04	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.23.2	\N	\N	5522191348
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2024-05-12 13:56:36.870542	58	EXECUTED	9:139b79bcbbfe903bb1c2d2a4dbf001d9	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.23.2	\N	\N	5522191348
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2024-05-12 13:56:36.938224	59	EXECUTED	9:b55738ad889860c625ba2bf483495a04	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.23.2	\N	\N	5522191348
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2024-05-12 13:56:36.951485	60	EXECUTED	9:e0057eac39aa8fc8e09ac6cfa4ae15fe	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.23.2	\N	\N	5522191348
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2024-05-12 13:56:36.968623	61	EXECUTED	9:42a33806f3a0443fe0e7feeec821326c	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.23.2	\N	\N	5522191348
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2024-05-12 13:56:36.981295	62	EXECUTED	9:9968206fca46eecc1f51db9c024bfe56	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.23.2	\N	\N	5522191348
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2024-05-12 13:56:36.988322	63	EXECUTED	9:92143a6daea0a3f3b8f598c97ce55c3d	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.23.2	\N	\N	5522191348
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2024-05-12 13:56:36.99419	64	EXECUTED	9:82bab26a27195d889fb0429003b18f40	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.23.2	\N	\N	5522191348
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2024-05-12 13:56:36.999759	65	EXECUTED	9:e590c88ddc0b38b0ae4249bbfcb5abc3	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.23.2	\N	\N	5522191348
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2024-05-12 13:56:37.032052	66	EXECUTED	9:5c1f475536118dbdc38d5d7977950cc0	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.23.2	\N	\N	5522191348
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2024-05-12 13:56:37.045448	67	EXECUTED	9:e7c9f5f9c4d67ccbbcc215440c718a17	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.23.2	\N	\N	5522191348
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2024-05-12 13:56:37.057268	68	EXECUTED	9:88e0bfdda924690d6f4e430c53447dd5	addColumn tableName=REALM		\N	4.23.2	\N	\N	5522191348
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2024-05-12 13:56:37.080474	69	EXECUTED	9:f53177f137e1c46b6a88c59ec1cb5218	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.23.2	\N	\N	5522191348
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2024-05-12 13:56:37.09041	70	EXECUTED	9:a74d33da4dc42a37ec27121580d1459f	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.23.2	\N	\N	5522191348
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2024-05-12 13:56:37.099236	71	EXECUTED	9:fd4ade7b90c3b67fae0bfcfcb42dfb5f	addColumn tableName=RESOURCE_SERVER		\N	4.23.2	\N	\N	5522191348
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-05-12 13:56:37.111191	72	EXECUTED	9:aa072ad090bbba210d8f18781b8cebf4	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.23.2	\N	\N	5522191348
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-05-12 13:56:37.121799	73	EXECUTED	9:1ae6be29bab7c2aa376f6983b932be37	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.23.2	\N	\N	5522191348
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-05-12 13:56:37.126101	74	MARK_RAN	9:14706f286953fc9a25286dbd8fb30d97	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.23.2	\N	\N	5522191348
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-05-12 13:56:37.186474	75	EXECUTED	9:2b9cc12779be32c5b40e2e67711a218b	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.23.2	\N	\N	5522191348
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2024-05-12 13:56:37.205197	76	EXECUTED	9:91fa186ce7a5af127a2d7a91ee083cc5	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.23.2	\N	\N	5522191348
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2024-05-12 13:56:37.2143	77	EXECUTED	9:6335e5c94e83a2639ccd68dd24e2e5ad	addColumn tableName=CLIENT		\N	4.23.2	\N	\N	5522191348
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2024-05-12 13:56:37.217793	78	MARK_RAN	9:6bdb5658951e028bfe16fa0a8228b530	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.23.2	\N	\N	5522191348
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2024-05-12 13:56:37.289103	79	EXECUTED	9:d5bc15a64117ccad481ce8792d4c608f	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.23.2	\N	\N	5522191348
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2024-05-12 13:56:37.296218	80	MARK_RAN	9:077cba51999515f4d3e7ad5619ab592c	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.23.2	\N	\N	5522191348
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-05-12 13:56:37.311655	81	EXECUTED	9:be969f08a163bf47c6b9e9ead8ac2afb	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.23.2	\N	\N	5522191348
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-05-12 13:56:37.314384	82	MARK_RAN	9:6d3bb4408ba5a72f39bd8a0b301ec6e3	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.23.2	\N	\N	5522191348
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-05-12 13:56:37.323196	83	EXECUTED	9:966bda61e46bebf3cc39518fbed52fa7	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.23.2	\N	\N	5522191348
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-05-12 13:56:37.327392	84	MARK_RAN	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.23.2	\N	\N	5522191348
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2024-05-12 13:56:37.341201	85	EXECUTED	9:7d93d602352a30c0c317e6a609b56599	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.23.2	\N	\N	5522191348
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2024-05-12 13:56:37.403388	86	EXECUTED	9:71c5969e6cdd8d7b6f47cebc86d37627	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.23.2	\N	\N	5522191348
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2024-05-12 13:56:37.418066	87	EXECUTED	9:a9ba7d47f065f041b7da856a81762021	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.23.2	\N	\N	5522191348
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2024-05-12 13:56:37.445852	88	EXECUTED	9:fffabce2bc01e1a8f5110d5278500065	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.23.2	\N	\N	5522191348
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-05-12 13:56:37.458708	89	EXECUTED	9:fa8a5b5445e3857f4b010bafb5009957	addColumn tableName=REALM; customChange		\N	4.23.2	\N	\N	5522191348
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-05-12 13:56:37.477101	90	EXECUTED	9:67ac3241df9a8582d591c5ed87125f39	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.23.2	\N	\N	5522191348
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-05-12 13:56:37.490241	91	EXECUTED	9:ad1194d66c937e3ffc82386c050ba089	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.23.2	\N	\N	5522191348
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-05-12 13:56:37.504251	92	EXECUTED	9:d9be619d94af5a2f5d07b9f003543b91	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.23.2	\N	\N	5522191348
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-05-12 13:56:37.508184	93	MARK_RAN	9:544d201116a0fcc5a5da0925fbbc3bde	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.23.2	\N	\N	5522191348
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-05-12 13:56:37.52555	94	EXECUTED	9:43c0c1055b6761b4b3e89de76d612ccf	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.23.2	\N	\N	5522191348
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-05-12 13:56:37.53159	95	MARK_RAN	9:8bd711fd0330f4fe980494ca43ab1139	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.23.2	\N	\N	5522191348
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2024-05-12 13:56:37.555297	96	EXECUTED	9:e07d2bc0970c348bb06fb63b1f82ddbf	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.23.2	\N	\N	5522191348
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-05-12 13:56:37.58196	97	EXECUTED	9:24fb8611e97f29989bea412aa38d12b7	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.23.2	\N	\N	5522191348
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-05-12 13:56:37.586576	98	MARK_RAN	9:259f89014ce2506ee84740cbf7163aa7	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	5522191348
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-05-12 13:56:37.600411	99	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	5522191348
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-05-12 13:56:37.614516	100	EXECUTED	9:60ca84a0f8c94ec8c3504a5a3bc88ee8	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	5522191348
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-05-12 13:56:37.618673	101	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	5522191348
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-05-12 13:56:37.63447	102	EXECUTED	9:0b305d8d1277f3a89a0a53a659ad274c	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.23.2	\N	\N	5522191348
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2024-05-12 13:56:37.643495	103	EXECUTED	9:2c374ad2cdfe20e2905a84c8fac48460	customChange		\N	4.23.2	\N	\N	5522191348
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2024-05-12 13:56:37.658215	104	EXECUTED	9:47a760639ac597360a8219f5b768b4de	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.23.2	\N	\N	5522191348
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2024-05-12 13:56:37.686959	105	EXECUTED	9:a6272f0576727dd8cad2522335f5d99e	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.23.2	\N	\N	5522191348
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2024-05-12 13:56:37.709732	106	EXECUTED	9:015479dbd691d9cc8669282f4828c41d	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.23.2	\N	\N	5522191348
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2024-05-12 13:56:37.71906	107	EXECUTED	9:9518e495fdd22f78ad6425cc30630221	customChange		\N	4.23.2	\N	\N	5522191348
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2024-05-12 13:56:37.732707	108	EXECUTED	9:e5f243877199fd96bcc842f27a1656ac	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.23.2	\N	\N	5522191348
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2024-05-12 13:56:37.737071	109	MARK_RAN	9:1a6fcaa85e20bdeae0a9ce49b41946a5	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.23.2	\N	\N	5522191348
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2024-05-12 13:56:37.752613	110	EXECUTED	9:3f332e13e90739ed0c35b0b25b7822ca	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.23.2	\N	\N	5522191348
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2024-05-12 13:56:37.761478	111	EXECUTED	9:7ee1f7a3fb8f5588f171fb9a6ab623c0	customChange		\N	4.23.2	\N	\N	5522191348
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2024-05-12 13:56:37.840405	112	EXECUTED	9:3d7e830b52f33676b9d64f7f2b2ea634	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.23.2	\N	\N	5522191348
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2024-05-12 13:56:37.849962	113	MARK_RAN	9:627d032e3ef2c06c0e1f73d2ae25c26c	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.23.2	\N	\N	5522191348
22.0.0-17484-updated	keycloak	META-INF/jpa-changelog-22.0.0.xml	2024-05-12 13:56:37.86516	114	EXECUTED	9:90af0bfd30cafc17b9f4d6eccd92b8b3	customChange		\N	4.23.2	\N	\N	5522191348
22.0.5-24031	keycloak	META-INF/jpa-changelog-22.0.0.xml	2024-05-12 13:56:37.868983	115	MARK_RAN	9:a60d2d7b315ec2d3eba9e2f145f9df28	customChange		\N	4.23.2	\N	\N	5522191348
23.0.0-12062	keycloak	META-INF/jpa-changelog-23.0.0.xml	2024-05-12 13:56:37.883689	116	EXECUTED	9:2168fbe728fec46ae9baf15bf80927b8	addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG		\N	4.23.2	\N	\N	5522191348
23.0.0-17258	keycloak	META-INF/jpa-changelog-23.0.0.xml	2024-05-12 13:56:37.892446	117	EXECUTED	9:36506d679a83bbfda85a27ea1864dca8	addColumn tableName=EVENT_ENTITY		\N	4.23.2	\N	\N	5522191348
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
1001	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
962fdb71-b4bb-438b-80ec-044eefbde5ed	ab7dbad7-62e1-4e95-91b0-607746b9c05c	f
962fdb71-b4bb-438b-80ec-044eefbde5ed	5d166388-f1c1-4d92-a126-67dd72f95f06	t
962fdb71-b4bb-438b-80ec-044eefbde5ed	266b0a2d-c5b3-48da-8009-10e1d50355a8	t
962fdb71-b4bb-438b-80ec-044eefbde5ed	55a0393a-5a32-498b-ab88-270bc2f5a150	t
962fdb71-b4bb-438b-80ec-044eefbde5ed	802997ab-56a5-437c-94aa-6463ff9c9213	f
962fdb71-b4bb-438b-80ec-044eefbde5ed	2dbf10c9-a964-44ec-916b-ca5a590155e6	f
962fdb71-b4bb-438b-80ec-044eefbde5ed	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a	t
962fdb71-b4bb-438b-80ec-044eefbde5ed	34569064-f04c-44fb-8c1c-bad44d91785a	t
962fdb71-b4bb-438b-80ec-044eefbde5ed	286700a8-8570-44b0-b677-87b5376bd900	f
962fdb71-b4bb-438b-80ec-044eefbde5ed	c97b85ed-40c1-4353-a8bb-7f82c93510fc	t
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id, details_json_long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.keycloak_group (id, name, parent_group, realm_id) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
750bcd16-aced-4fce-bd44-1d0433981651	962fdb71-b4bb-438b-80ec-044eefbde5ed	f	${role_default-roles}	default-roles-master	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N	\N
a53bb093-34f1-4b39-b476-988513f41669	962fdb71-b4bb-438b-80ec-044eefbde5ed	f	${role_admin}	admin	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N	\N
b3097298-292b-4640-9a78-4fe80f96b4e4	962fdb71-b4bb-438b-80ec-044eefbde5ed	f	${role_create-realm}	create-realm	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N	\N
eb237a7c-a9bd-479c-a366-cd38fc95d517	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_create-client}	create-client	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
de86a0cb-b992-46b6-946f-7fcfc749f809	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_view-realm}	view-realm	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
1ad417dd-3526-4d2a-a913-01122535826c	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_view-users}	view-users	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
a4446929-cef0-4ca9-a696-77dc813f3032	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_view-clients}	view-clients	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
9af40611-fd75-44bd-8924-777da0f778bd	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_view-events}	view-events	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
fc44b785-300a-4c83-9cb3-853fe6ecc86e	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_view-identity-providers}	view-identity-providers	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
fae91039-60ee-4f33-addd-a448ca3f6c80	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_view-authorization}	view-authorization	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
cc5cd6d7-efc9-41e0-8954-a651101c459c	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_manage-realm}	manage-realm	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
264bbe1f-a11f-4cb5-83c9-338fa900d220	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_manage-users}	manage-users	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
44b52c9d-df3d-4f0e-8a4c-d3e2fd982869	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_manage-clients}	manage-clients	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
64b10bd1-205d-4b21-9417-53440ed1e548	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_manage-events}	manage-events	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
b4abe05c-bee9-4c38-a1c1-94cd5fa01f19	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_manage-identity-providers}	manage-identity-providers	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
55cc23ad-4d8d-418a-bf04-dbb3ec11cfff	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_manage-authorization}	manage-authorization	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
6230393a-f464-43ee-83d0-9043d56e5bcb	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_query-users}	query-users	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
e0800b7e-0424-42dc-b7c9-40ad74f586cd	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_query-clients}	query-clients	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
1fb5a3d0-a1d8-479e-a8c6-55ab9866178b	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_query-realms}	query-realms	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
7d201047-5ced-42d4-85fc-6c79da044b0f	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_query-groups}	query-groups	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
47692916-0d03-49da-814a-73e69b02688c	294ab06e-9ea6-48c3-8166-59b00af63675	t	${role_view-profile}	view-profile	962fdb71-b4bb-438b-80ec-044eefbde5ed	294ab06e-9ea6-48c3-8166-59b00af63675	\N
147c66c3-511f-49c0-8552-d174b1dff0e5	294ab06e-9ea6-48c3-8166-59b00af63675	t	${role_manage-account}	manage-account	962fdb71-b4bb-438b-80ec-044eefbde5ed	294ab06e-9ea6-48c3-8166-59b00af63675	\N
844d9b28-ef3b-47cb-ac59-5a5b93b0e2d0	294ab06e-9ea6-48c3-8166-59b00af63675	t	${role_manage-account-links}	manage-account-links	962fdb71-b4bb-438b-80ec-044eefbde5ed	294ab06e-9ea6-48c3-8166-59b00af63675	\N
999561ca-3948-46b2-a45d-c6f3988d43c9	294ab06e-9ea6-48c3-8166-59b00af63675	t	${role_view-applications}	view-applications	962fdb71-b4bb-438b-80ec-044eefbde5ed	294ab06e-9ea6-48c3-8166-59b00af63675	\N
adce559b-7430-4a3b-ab91-40196022a32b	294ab06e-9ea6-48c3-8166-59b00af63675	t	${role_view-consent}	view-consent	962fdb71-b4bb-438b-80ec-044eefbde5ed	294ab06e-9ea6-48c3-8166-59b00af63675	\N
7f1152b6-4111-4584-b75a-6d989ed8f07d	294ab06e-9ea6-48c3-8166-59b00af63675	t	${role_manage-consent}	manage-consent	962fdb71-b4bb-438b-80ec-044eefbde5ed	294ab06e-9ea6-48c3-8166-59b00af63675	\N
03dac675-0d0e-467d-b30b-608ac6d834f6	294ab06e-9ea6-48c3-8166-59b00af63675	t	${role_view-groups}	view-groups	962fdb71-b4bb-438b-80ec-044eefbde5ed	294ab06e-9ea6-48c3-8166-59b00af63675	\N
c57dbcf1-2bd0-43b4-94ae-fab8108314b9	294ab06e-9ea6-48c3-8166-59b00af63675	t	${role_delete-account}	delete-account	962fdb71-b4bb-438b-80ec-044eefbde5ed	294ab06e-9ea6-48c3-8166-59b00af63675	\N
ce2b99ad-8395-4ea8-ab7f-9f8db45b6585	0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	t	${role_read-token}	read-token	962fdb71-b4bb-438b-80ec-044eefbde5ed	0476eaa6-8fe8-4f4f-a026-65cf108a5cc2	\N
cc763a79-b99d-480f-8c36-67d9a19fb733	b48b1bb4-1735-462a-95b3-ffd0f907068f	t	${role_impersonation}	impersonation	962fdb71-b4bb-438b-80ec-044eefbde5ed	b48b1bb4-1735-462a-95b3-ffd0f907068f	\N
e21f7203-111b-4944-9b12-8a27c5d62b62	962fdb71-b4bb-438b-80ec-044eefbde5ed	f	${role_offline-access}	offline_access	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N	\N
58eca589-9888-4c78-b0e7-4f485654ecb7	962fdb71-b4bb-438b-80ec-044eefbde5ed	f	${role_uma_authorization}	uma_authorization	962fdb71-b4bb-438b-80ec-044eefbde5ed	\N	\N
aaa780ef-c923-4c67-add2-20049b03f350	c758c45c-a01d-4800-b5d2-dfde4a30a492	t	\N	uma_protection	962fdb71-b4bb-438b-80ec-044eefbde5ed	c758c45c-a01d-4800-b5d2-dfde4a30a492	\N
2ce99a16-fd1f-4729-bd5e-43b20c67d44c	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	t	\N	uma_protection	962fdb71-b4bb-438b-80ec-044eefbde5ed	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	\N
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	t	HOLACRACY_USER	HOLACRACY_USER	962fdb71-b4bb-438b-80ec-044eefbde5ed	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	\N
5d81b2af-cd46-42c8-aa99-d47c49c4d4be	352ef396-c83f-4ed8-8c47-23cc928864aa	t	\N	uma_protection	962fdb71-b4bb-438b-80ec-044eefbde5ed	352ef396-c83f-4ed8-8c47-23cc928864aa	\N
09c9fddb-944d-458a-aeed-8c4e9771aa72	009f96bb-01ae-4ec5-93b5-88853bc82364	t	\N	uma_protection	962fdb71-b4bb-438b-80ec-044eefbde5ed	009f96bb-01ae-4ec5-93b5-88853bc82364	\N
1f227b2a-85fb-4984-880e-34dde6aa37b4	2c111030-ed95-40ff-9976-12c8cd399083	t	\N	uma_protection	962fdb71-b4bb-438b-80ec-044eefbde5ed	2c111030-ed95-40ff-9976-12c8cd399083	\N
f9d4ace7-c619-4a1f-a0e3-1113d8e5d31f	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	t	\N	uma_protection	962fdb71-b4bb-438b-80ec-044eefbde5ed	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	\N
5d4df64f-51eb-4214-b9f1-eb3f8c991978	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	t	\N	uma_protection	962fdb71-b4bb-438b-80ec-044eefbde5ed	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	\N
29654c7c-f86d-4e90-8c2f-98212b3b4c59	5c13758d-f499-47ee-94cf-c97563dcb644	t	\N	uma_protection	962fdb71-b4bb-438b-80ec-044eefbde5ed	5c13758d-f499-47ee-94cf-c97563dcb644	\N
e7698f94-85ac-4bd2-9c4a-1aa3dd809bd6	4d0ebf75-767a-4542-bbbe-7910f9096a7d	t	\N	uma_protection	962fdb71-b4bb-438b-80ec-044eefbde5ed	4d0ebf75-767a-4542-bbbe-7910f9096a7d	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.migration_model (id, version, update_time) FROM stdin;
laky3	23.0.7	1715522198
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
e4cd3c3a-b093-40aa-9bb4-2bb2d8ec9a62	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
78aac6ea-271f-4a33-860e-37f9a9da06bb	defaultResourceType	urn:gaian:resources:default
b6334ce6-a38e-4c63-a834-c04917885c4e	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
5e886ca6-0cf6-47fb-8cfd-c14d2e323ae5	defaultResourceType	urn:HOLACRACY:resources:default
6ecddc8f-729b-4b64-93be-e851e345c0fc	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
fd00e3d6-ed90-4faa-b279-ed8da558fdb1	defaultResourceType	urn:mllmi:resources:default
e65221f4-8bce-4074-a82d-deb6af0bb80f	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
73b631ec-69cd-4a9d-9568-130374c0e5c0	defaultResourceType	urn:bbemk:resources:default
67cbece1-f2be-404f-90fb-ae7af173b61e	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
aedc057b-7202-46f5-9478-7ef82f0e3a54	defaultResourceType	urn:fkdkj:resources:default
ea8535a9-b65d-4012-a40a-b1bdd73b29b1	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
7daf3601-074b-4ab9-babe-6c4712df1a99	defaultResourceType	urn:hmeid:resources:default
6a1dba2e-1e31-4673-aaf7-44a705f8793d	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
1cb8b12c-78f4-4090-a0ea-89f070199e16	defaultResourceType	urn:jhjla:resources:default
456adab1-163b-42ed-81a3-dd5dfa87aba2	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
bc89b137-11a8-42d4-9128-189775120a67	defaultResourceType	urn:lkfjj:resources:default
f874c5ea-c81b-4dc1-87c6-3b70d355dec3	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
c2a5d1a5-f3c5-4c62-84e4-4a4838523125	defaultResourceType	urn:dgjjh:resources:default
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
63797eb3-739f-4f28-a988-554bcc8ec6d5	audience resolve	openid-connect	oidc-audience-resolve-mapper	7d95546a-c3b7-410a-8bb0-fbb3eb99af76	\N
530fdd67-a5af-45a3-9a14-69124f9c908e	locale	openid-connect	oidc-usermodel-attribute-mapper	e1eabf61-45a2-4b63-936d-d1ce68866ada	\N
e7a5cd3b-b42c-409a-bfc5-d5a288e9cdff	role list	saml	saml-role-list-mapper	\N	5d166388-f1c1-4d92-a126-67dd72f95f06
031de863-67ab-453d-bd09-ab169cd2df0d	full name	openid-connect	oidc-full-name-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
7bc962d6-d757-4abd-a02e-a2b3f0084a08	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
0c1a0a94-8554-47fe-8b40-f369d16ec2a9	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
24934e7e-0031-40e4-9baa-68459e45cf6e	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
7a190dba-40cf-48fc-a54b-ec43fe1f5460	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
7f7011f7-e218-4127-b7e1-fbfb3a6547ae	username	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
aef86a63-00bd-4aca-a46d-c7e7ab4a7fff	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
85aeaa3a-fbce-4c13-940f-162d79df1d5e	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
6026b39c-6be6-4585-8856-d00399075468	website	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
c7539b7d-086c-45f4-b90c-b89aabf4d3cb	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
6ae4ab45-e00b-448a-a914-5e3bf5d6bb96	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
818bdedf-e3b8-4785-a37f-8c15238a44c5	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
657b6f4e-8f32-442c-91f8-49056046ee89	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
4d94722e-03e0-4c86-9ffe-57747f997639	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	266b0a2d-c5b3-48da-8009-10e1d50355a8
438a6609-b9e9-4c9b-b614-c878d61e1e0a	email	openid-connect	oidc-usermodel-attribute-mapper	\N	55a0393a-5a32-498b-ab88-270bc2f5a150
5ce83aa3-1e98-4aa8-bf05-9161e44fb109	email verified	openid-connect	oidc-usermodel-property-mapper	\N	55a0393a-5a32-498b-ab88-270bc2f5a150
b042af93-9b46-4190-8d44-ce264f655ba1	address	openid-connect	oidc-address-mapper	\N	802997ab-56a5-437c-94aa-6463ff9c9213
f9ac7990-a6b9-40e0-9c3c-111ccda75727	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	2dbf10c9-a964-44ec-916b-ca5a590155e6
4944eb3a-24e5-4368-afaf-ecfa4df4bf79	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	2dbf10c9-a964-44ec-916b-ca5a590155e6
4093a12c-88c3-4e1d-a170-2044894dec90	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a
1b0ef31e-1dde-4966-ad77-17a5ca808127	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a
6836b417-227e-4d8f-b81a-da30f177179d	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	b4f5f0a3-9e82-48e2-9497-5956f0bfa64a
2d3af9fe-c32c-4a0d-8146-eae5be18b112	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	34569064-f04c-44fb-8c1c-bad44d91785a
520abc16-dda6-448d-a5cd-4df98035abba	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	286700a8-8570-44b0-b677-87b5376bd900
0977b787-d0ae-44c6-a424-608af919d70a	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	286700a8-8570-44b0-b677-87b5376bd900
87551d05-6e16-4635-ac36-e3aab33e4715	acr loa level	openid-connect	oidc-acr-mapper	\N	c97b85ed-40c1-4353-a8bb-7f82c93510fc
9b28f049-1720-450e-b3ca-30d6b2425b54	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	c758c45c-a01d-4800-b5d2-dfde4a30a492	\N
ca6a6332-f1d6-4fcc-9562-3d161682fa64	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	c758c45c-a01d-4800-b5d2-dfde4a30a492	\N
f6066053-91e1-4094-91ff-cb59f0ebb6fa	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	c758c45c-a01d-4800-b5d2-dfde4a30a492	\N
3eb14da6-f3cd-4ab0-b610-fd5564141687	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	\N
c1d90130-3ed1-422f-a9a0-14706436dae9	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	\N
24441897-55e2-487b-a803-8eeec9bde52a	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	\N
16fa3ff7-3d31-4258-98b9-e86eb2935916	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	352ef396-c83f-4ed8-8c47-23cc928864aa	\N
2b8cacd2-3431-4030-a8d5-884a52a43572	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	352ef396-c83f-4ed8-8c47-23cc928864aa	\N
64a96539-8f31-4f7e-b374-00cf5a575b6a	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	352ef396-c83f-4ed8-8c47-23cc928864aa	\N
767968ea-8113-44fa-a7fc-88e400ce95e6	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	2c111030-ed95-40ff-9976-12c8cd399083	\N
3ef478cb-9675-4266-81dd-b66d36d2e5c1	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	2c111030-ed95-40ff-9976-12c8cd399083	\N
8d021345-00d0-477d-9769-0bcc0f325a94	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	2c111030-ed95-40ff-9976-12c8cd399083	\N
bc3075d9-c798-4708-afb0-88009ca492b6	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	\N
b9d4ff45-04f0-4b98-b701-c1b171a40adc	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	\N
9613033f-3632-45b5-a3a6-59d7400af061	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	\N
4b8b90c5-8294-4cd4-be89-f624366214c2	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	\N
0c939dcc-86a0-4294-90f8-40a65aa0d25e	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	\N
f883759a-86f0-4b0e-a80f-a10386c1db50	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	\N
7daa8d70-c2ff-45a2-849d-c46813e1cb37	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	009f96bb-01ae-4ec5-93b5-88853bc82364	\N
7afb2a04-b370-42a0-8026-6779a14f7965	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	009f96bb-01ae-4ec5-93b5-88853bc82364	\N
4cf6b556-9bea-4635-8510-1e144da2897b	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	009f96bb-01ae-4ec5-93b5-88853bc82364	\N
dbf1f81d-a9b3-44a4-96c7-6f10fc10f187	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	5c13758d-f499-47ee-94cf-c97563dcb644	\N
5af61f5b-b629-4c89-993f-cec8b472d65b	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	5c13758d-f499-47ee-94cf-c97563dcb644	\N
c693cfa7-f2db-4c1a-b944-c4ba1f3509e3	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	5c13758d-f499-47ee-94cf-c97563dcb644	\N
4e3ca504-e10d-4e23-bdfc-67ea1cd64eef	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	4d0ebf75-767a-4542-bbbe-7910f9096a7d	\N
5160da42-a5a0-40a4-9ef6-3a8a96e2b009	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	4d0ebf75-767a-4542-bbbe-7910f9096a7d	\N
71dbd4ff-d73c-475c-9388-e09e57b7db83	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	4d0ebf75-767a-4542-bbbe-7910f9096a7d	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
530fdd67-a5af-45a3-9a14-69124f9c908e	true	introspection.token.claim
530fdd67-a5af-45a3-9a14-69124f9c908e	true	userinfo.token.claim
530fdd67-a5af-45a3-9a14-69124f9c908e	locale	user.attribute
530fdd67-a5af-45a3-9a14-69124f9c908e	true	id.token.claim
530fdd67-a5af-45a3-9a14-69124f9c908e	true	access.token.claim
530fdd67-a5af-45a3-9a14-69124f9c908e	locale	claim.name
530fdd67-a5af-45a3-9a14-69124f9c908e	String	jsonType.label
e7a5cd3b-b42c-409a-bfc5-d5a288e9cdff	false	single
e7a5cd3b-b42c-409a-bfc5-d5a288e9cdff	Basic	attribute.nameformat
e7a5cd3b-b42c-409a-bfc5-d5a288e9cdff	Role	attribute.name
031de863-67ab-453d-bd09-ab169cd2df0d	true	introspection.token.claim
031de863-67ab-453d-bd09-ab169cd2df0d	true	userinfo.token.claim
031de863-67ab-453d-bd09-ab169cd2df0d	true	id.token.claim
031de863-67ab-453d-bd09-ab169cd2df0d	true	access.token.claim
0c1a0a94-8554-47fe-8b40-f369d16ec2a9	true	introspection.token.claim
0c1a0a94-8554-47fe-8b40-f369d16ec2a9	true	userinfo.token.claim
0c1a0a94-8554-47fe-8b40-f369d16ec2a9	firstName	user.attribute
0c1a0a94-8554-47fe-8b40-f369d16ec2a9	true	id.token.claim
0c1a0a94-8554-47fe-8b40-f369d16ec2a9	true	access.token.claim
0c1a0a94-8554-47fe-8b40-f369d16ec2a9	given_name	claim.name
0c1a0a94-8554-47fe-8b40-f369d16ec2a9	String	jsonType.label
24934e7e-0031-40e4-9baa-68459e45cf6e	true	introspection.token.claim
24934e7e-0031-40e4-9baa-68459e45cf6e	true	userinfo.token.claim
24934e7e-0031-40e4-9baa-68459e45cf6e	middleName	user.attribute
24934e7e-0031-40e4-9baa-68459e45cf6e	true	id.token.claim
24934e7e-0031-40e4-9baa-68459e45cf6e	true	access.token.claim
24934e7e-0031-40e4-9baa-68459e45cf6e	middle_name	claim.name
24934e7e-0031-40e4-9baa-68459e45cf6e	String	jsonType.label
4d94722e-03e0-4c86-9ffe-57747f997639	true	introspection.token.claim
4d94722e-03e0-4c86-9ffe-57747f997639	true	userinfo.token.claim
4d94722e-03e0-4c86-9ffe-57747f997639	updatedAt	user.attribute
4d94722e-03e0-4c86-9ffe-57747f997639	true	id.token.claim
4d94722e-03e0-4c86-9ffe-57747f997639	true	access.token.claim
4d94722e-03e0-4c86-9ffe-57747f997639	updated_at	claim.name
4d94722e-03e0-4c86-9ffe-57747f997639	long	jsonType.label
6026b39c-6be6-4585-8856-d00399075468	true	introspection.token.claim
6026b39c-6be6-4585-8856-d00399075468	true	userinfo.token.claim
6026b39c-6be6-4585-8856-d00399075468	website	user.attribute
6026b39c-6be6-4585-8856-d00399075468	true	id.token.claim
6026b39c-6be6-4585-8856-d00399075468	true	access.token.claim
6026b39c-6be6-4585-8856-d00399075468	website	claim.name
6026b39c-6be6-4585-8856-d00399075468	String	jsonType.label
657b6f4e-8f32-442c-91f8-49056046ee89	true	introspection.token.claim
657b6f4e-8f32-442c-91f8-49056046ee89	true	userinfo.token.claim
657b6f4e-8f32-442c-91f8-49056046ee89	locale	user.attribute
657b6f4e-8f32-442c-91f8-49056046ee89	true	id.token.claim
657b6f4e-8f32-442c-91f8-49056046ee89	true	access.token.claim
657b6f4e-8f32-442c-91f8-49056046ee89	locale	claim.name
657b6f4e-8f32-442c-91f8-49056046ee89	String	jsonType.label
6ae4ab45-e00b-448a-a914-5e3bf5d6bb96	true	introspection.token.claim
6ae4ab45-e00b-448a-a914-5e3bf5d6bb96	true	userinfo.token.claim
6ae4ab45-e00b-448a-a914-5e3bf5d6bb96	birthdate	user.attribute
6ae4ab45-e00b-448a-a914-5e3bf5d6bb96	true	id.token.claim
6ae4ab45-e00b-448a-a914-5e3bf5d6bb96	true	access.token.claim
6ae4ab45-e00b-448a-a914-5e3bf5d6bb96	birthdate	claim.name
6ae4ab45-e00b-448a-a914-5e3bf5d6bb96	String	jsonType.label
7a190dba-40cf-48fc-a54b-ec43fe1f5460	true	introspection.token.claim
7a190dba-40cf-48fc-a54b-ec43fe1f5460	true	userinfo.token.claim
7a190dba-40cf-48fc-a54b-ec43fe1f5460	nickname	user.attribute
7a190dba-40cf-48fc-a54b-ec43fe1f5460	true	id.token.claim
7a190dba-40cf-48fc-a54b-ec43fe1f5460	true	access.token.claim
7a190dba-40cf-48fc-a54b-ec43fe1f5460	nickname	claim.name
7a190dba-40cf-48fc-a54b-ec43fe1f5460	String	jsonType.label
7bc962d6-d757-4abd-a02e-a2b3f0084a08	true	introspection.token.claim
7bc962d6-d757-4abd-a02e-a2b3f0084a08	true	userinfo.token.claim
7bc962d6-d757-4abd-a02e-a2b3f0084a08	lastName	user.attribute
7bc962d6-d757-4abd-a02e-a2b3f0084a08	true	id.token.claim
7bc962d6-d757-4abd-a02e-a2b3f0084a08	true	access.token.claim
7bc962d6-d757-4abd-a02e-a2b3f0084a08	family_name	claim.name
7bc962d6-d757-4abd-a02e-a2b3f0084a08	String	jsonType.label
7f7011f7-e218-4127-b7e1-fbfb3a6547ae	true	introspection.token.claim
7f7011f7-e218-4127-b7e1-fbfb3a6547ae	true	userinfo.token.claim
7f7011f7-e218-4127-b7e1-fbfb3a6547ae	username	user.attribute
7f7011f7-e218-4127-b7e1-fbfb3a6547ae	true	id.token.claim
7f7011f7-e218-4127-b7e1-fbfb3a6547ae	true	access.token.claim
7f7011f7-e218-4127-b7e1-fbfb3a6547ae	preferred_username	claim.name
7f7011f7-e218-4127-b7e1-fbfb3a6547ae	String	jsonType.label
818bdedf-e3b8-4785-a37f-8c15238a44c5	true	introspection.token.claim
818bdedf-e3b8-4785-a37f-8c15238a44c5	true	userinfo.token.claim
818bdedf-e3b8-4785-a37f-8c15238a44c5	zoneinfo	user.attribute
818bdedf-e3b8-4785-a37f-8c15238a44c5	true	id.token.claim
818bdedf-e3b8-4785-a37f-8c15238a44c5	true	access.token.claim
818bdedf-e3b8-4785-a37f-8c15238a44c5	zoneinfo	claim.name
818bdedf-e3b8-4785-a37f-8c15238a44c5	String	jsonType.label
85aeaa3a-fbce-4c13-940f-162d79df1d5e	true	introspection.token.claim
85aeaa3a-fbce-4c13-940f-162d79df1d5e	true	userinfo.token.claim
85aeaa3a-fbce-4c13-940f-162d79df1d5e	picture	user.attribute
85aeaa3a-fbce-4c13-940f-162d79df1d5e	true	id.token.claim
85aeaa3a-fbce-4c13-940f-162d79df1d5e	true	access.token.claim
85aeaa3a-fbce-4c13-940f-162d79df1d5e	picture	claim.name
85aeaa3a-fbce-4c13-940f-162d79df1d5e	String	jsonType.label
aef86a63-00bd-4aca-a46d-c7e7ab4a7fff	true	introspection.token.claim
aef86a63-00bd-4aca-a46d-c7e7ab4a7fff	true	userinfo.token.claim
aef86a63-00bd-4aca-a46d-c7e7ab4a7fff	profile	user.attribute
aef86a63-00bd-4aca-a46d-c7e7ab4a7fff	true	id.token.claim
aef86a63-00bd-4aca-a46d-c7e7ab4a7fff	true	access.token.claim
aef86a63-00bd-4aca-a46d-c7e7ab4a7fff	profile	claim.name
aef86a63-00bd-4aca-a46d-c7e7ab4a7fff	String	jsonType.label
c7539b7d-086c-45f4-b90c-b89aabf4d3cb	true	introspection.token.claim
c7539b7d-086c-45f4-b90c-b89aabf4d3cb	true	userinfo.token.claim
c7539b7d-086c-45f4-b90c-b89aabf4d3cb	gender	user.attribute
c7539b7d-086c-45f4-b90c-b89aabf4d3cb	true	id.token.claim
c7539b7d-086c-45f4-b90c-b89aabf4d3cb	true	access.token.claim
c7539b7d-086c-45f4-b90c-b89aabf4d3cb	gender	claim.name
c7539b7d-086c-45f4-b90c-b89aabf4d3cb	String	jsonType.label
438a6609-b9e9-4c9b-b614-c878d61e1e0a	true	introspection.token.claim
438a6609-b9e9-4c9b-b614-c878d61e1e0a	true	userinfo.token.claim
438a6609-b9e9-4c9b-b614-c878d61e1e0a	email	user.attribute
438a6609-b9e9-4c9b-b614-c878d61e1e0a	true	id.token.claim
438a6609-b9e9-4c9b-b614-c878d61e1e0a	true	access.token.claim
438a6609-b9e9-4c9b-b614-c878d61e1e0a	email	claim.name
438a6609-b9e9-4c9b-b614-c878d61e1e0a	String	jsonType.label
5ce83aa3-1e98-4aa8-bf05-9161e44fb109	true	introspection.token.claim
5ce83aa3-1e98-4aa8-bf05-9161e44fb109	true	userinfo.token.claim
5ce83aa3-1e98-4aa8-bf05-9161e44fb109	emailVerified	user.attribute
5ce83aa3-1e98-4aa8-bf05-9161e44fb109	true	id.token.claim
5ce83aa3-1e98-4aa8-bf05-9161e44fb109	true	access.token.claim
5ce83aa3-1e98-4aa8-bf05-9161e44fb109	email_verified	claim.name
5ce83aa3-1e98-4aa8-bf05-9161e44fb109	boolean	jsonType.label
b042af93-9b46-4190-8d44-ce264f655ba1	formatted	user.attribute.formatted
b042af93-9b46-4190-8d44-ce264f655ba1	country	user.attribute.country
b042af93-9b46-4190-8d44-ce264f655ba1	true	introspection.token.claim
b042af93-9b46-4190-8d44-ce264f655ba1	postal_code	user.attribute.postal_code
b042af93-9b46-4190-8d44-ce264f655ba1	true	userinfo.token.claim
b042af93-9b46-4190-8d44-ce264f655ba1	street	user.attribute.street
b042af93-9b46-4190-8d44-ce264f655ba1	true	id.token.claim
b042af93-9b46-4190-8d44-ce264f655ba1	region	user.attribute.region
b042af93-9b46-4190-8d44-ce264f655ba1	true	access.token.claim
b042af93-9b46-4190-8d44-ce264f655ba1	locality	user.attribute.locality
4944eb3a-24e5-4368-afaf-ecfa4df4bf79	true	introspection.token.claim
4944eb3a-24e5-4368-afaf-ecfa4df4bf79	true	userinfo.token.claim
4944eb3a-24e5-4368-afaf-ecfa4df4bf79	phoneNumberVerified	user.attribute
4944eb3a-24e5-4368-afaf-ecfa4df4bf79	true	id.token.claim
4944eb3a-24e5-4368-afaf-ecfa4df4bf79	true	access.token.claim
4944eb3a-24e5-4368-afaf-ecfa4df4bf79	phone_number_verified	claim.name
4944eb3a-24e5-4368-afaf-ecfa4df4bf79	boolean	jsonType.label
f9ac7990-a6b9-40e0-9c3c-111ccda75727	true	introspection.token.claim
f9ac7990-a6b9-40e0-9c3c-111ccda75727	true	userinfo.token.claim
f9ac7990-a6b9-40e0-9c3c-111ccda75727	phoneNumber	user.attribute
f9ac7990-a6b9-40e0-9c3c-111ccda75727	true	id.token.claim
f9ac7990-a6b9-40e0-9c3c-111ccda75727	true	access.token.claim
f9ac7990-a6b9-40e0-9c3c-111ccda75727	phone_number	claim.name
f9ac7990-a6b9-40e0-9c3c-111ccda75727	String	jsonType.label
1b0ef31e-1dde-4966-ad77-17a5ca808127	true	introspection.token.claim
1b0ef31e-1dde-4966-ad77-17a5ca808127	true	multivalued
1b0ef31e-1dde-4966-ad77-17a5ca808127	foo	user.attribute
1b0ef31e-1dde-4966-ad77-17a5ca808127	true	access.token.claim
1b0ef31e-1dde-4966-ad77-17a5ca808127	resource_access.${client_id}.roles	claim.name
1b0ef31e-1dde-4966-ad77-17a5ca808127	String	jsonType.label
4093a12c-88c3-4e1d-a170-2044894dec90	true	introspection.token.claim
4093a12c-88c3-4e1d-a170-2044894dec90	true	multivalued
4093a12c-88c3-4e1d-a170-2044894dec90	foo	user.attribute
4093a12c-88c3-4e1d-a170-2044894dec90	true	access.token.claim
4093a12c-88c3-4e1d-a170-2044894dec90	realm_access.roles	claim.name
4093a12c-88c3-4e1d-a170-2044894dec90	String	jsonType.label
6836b417-227e-4d8f-b81a-da30f177179d	true	introspection.token.claim
6836b417-227e-4d8f-b81a-da30f177179d	true	access.token.claim
2d3af9fe-c32c-4a0d-8146-eae5be18b112	true	introspection.token.claim
2d3af9fe-c32c-4a0d-8146-eae5be18b112	true	access.token.claim
0977b787-d0ae-44c6-a424-608af919d70a	true	introspection.token.claim
0977b787-d0ae-44c6-a424-608af919d70a	true	multivalued
0977b787-d0ae-44c6-a424-608af919d70a	foo	user.attribute
0977b787-d0ae-44c6-a424-608af919d70a	true	id.token.claim
0977b787-d0ae-44c6-a424-608af919d70a	true	access.token.claim
0977b787-d0ae-44c6-a424-608af919d70a	groups	claim.name
0977b787-d0ae-44c6-a424-608af919d70a	String	jsonType.label
520abc16-dda6-448d-a5cd-4df98035abba	true	introspection.token.claim
520abc16-dda6-448d-a5cd-4df98035abba	true	userinfo.token.claim
520abc16-dda6-448d-a5cd-4df98035abba	username	user.attribute
520abc16-dda6-448d-a5cd-4df98035abba	true	id.token.claim
520abc16-dda6-448d-a5cd-4df98035abba	true	access.token.claim
520abc16-dda6-448d-a5cd-4df98035abba	upn	claim.name
520abc16-dda6-448d-a5cd-4df98035abba	String	jsonType.label
87551d05-6e16-4635-ac36-e3aab33e4715	true	introspection.token.claim
87551d05-6e16-4635-ac36-e3aab33e4715	true	id.token.claim
87551d05-6e16-4635-ac36-e3aab33e4715	true	access.token.claim
9b28f049-1720-450e-b3ca-30d6b2425b54	client_id	user.session.note
9b28f049-1720-450e-b3ca-30d6b2425b54	true	introspection.token.claim
9b28f049-1720-450e-b3ca-30d6b2425b54	true	id.token.claim
9b28f049-1720-450e-b3ca-30d6b2425b54	true	access.token.claim
9b28f049-1720-450e-b3ca-30d6b2425b54	client_id	claim.name
9b28f049-1720-450e-b3ca-30d6b2425b54	String	jsonType.label
ca6a6332-f1d6-4fcc-9562-3d161682fa64	clientHost	user.session.note
ca6a6332-f1d6-4fcc-9562-3d161682fa64	true	introspection.token.claim
ca6a6332-f1d6-4fcc-9562-3d161682fa64	true	id.token.claim
ca6a6332-f1d6-4fcc-9562-3d161682fa64	true	access.token.claim
ca6a6332-f1d6-4fcc-9562-3d161682fa64	clientHost	claim.name
ca6a6332-f1d6-4fcc-9562-3d161682fa64	String	jsonType.label
f6066053-91e1-4094-91ff-cb59f0ebb6fa	clientAddress	user.session.note
f6066053-91e1-4094-91ff-cb59f0ebb6fa	true	introspection.token.claim
f6066053-91e1-4094-91ff-cb59f0ebb6fa	true	id.token.claim
f6066053-91e1-4094-91ff-cb59f0ebb6fa	true	access.token.claim
f6066053-91e1-4094-91ff-cb59f0ebb6fa	clientAddress	claim.name
f6066053-91e1-4094-91ff-cb59f0ebb6fa	String	jsonType.label
24441897-55e2-487b-a803-8eeec9bde52a	clientAddress	user.session.note
24441897-55e2-487b-a803-8eeec9bde52a	true	introspection.token.claim
24441897-55e2-487b-a803-8eeec9bde52a	true	id.token.claim
24441897-55e2-487b-a803-8eeec9bde52a	true	access.token.claim
24441897-55e2-487b-a803-8eeec9bde52a	clientAddress	claim.name
24441897-55e2-487b-a803-8eeec9bde52a	String	jsonType.label
3eb14da6-f3cd-4ab0-b610-fd5564141687	client_id	user.session.note
3eb14da6-f3cd-4ab0-b610-fd5564141687	true	introspection.token.claim
3eb14da6-f3cd-4ab0-b610-fd5564141687	true	id.token.claim
3eb14da6-f3cd-4ab0-b610-fd5564141687	true	access.token.claim
3eb14da6-f3cd-4ab0-b610-fd5564141687	client_id	claim.name
3eb14da6-f3cd-4ab0-b610-fd5564141687	String	jsonType.label
c1d90130-3ed1-422f-a9a0-14706436dae9	clientHost	user.session.note
c1d90130-3ed1-422f-a9a0-14706436dae9	true	introspection.token.claim
c1d90130-3ed1-422f-a9a0-14706436dae9	true	id.token.claim
c1d90130-3ed1-422f-a9a0-14706436dae9	true	access.token.claim
c1d90130-3ed1-422f-a9a0-14706436dae9	clientHost	claim.name
c1d90130-3ed1-422f-a9a0-14706436dae9	String	jsonType.label
16fa3ff7-3d31-4258-98b9-e86eb2935916	client_id	user.session.note
16fa3ff7-3d31-4258-98b9-e86eb2935916	true	introspection.token.claim
16fa3ff7-3d31-4258-98b9-e86eb2935916	true	id.token.claim
16fa3ff7-3d31-4258-98b9-e86eb2935916	true	access.token.claim
16fa3ff7-3d31-4258-98b9-e86eb2935916	client_id	claim.name
16fa3ff7-3d31-4258-98b9-e86eb2935916	String	jsonType.label
2b8cacd2-3431-4030-a8d5-884a52a43572	clientHost	user.session.note
2b8cacd2-3431-4030-a8d5-884a52a43572	true	introspection.token.claim
2b8cacd2-3431-4030-a8d5-884a52a43572	true	id.token.claim
2b8cacd2-3431-4030-a8d5-884a52a43572	true	access.token.claim
2b8cacd2-3431-4030-a8d5-884a52a43572	clientHost	claim.name
2b8cacd2-3431-4030-a8d5-884a52a43572	String	jsonType.label
64a96539-8f31-4f7e-b374-00cf5a575b6a	clientAddress	user.session.note
64a96539-8f31-4f7e-b374-00cf5a575b6a	true	introspection.token.claim
64a96539-8f31-4f7e-b374-00cf5a575b6a	true	id.token.claim
64a96539-8f31-4f7e-b374-00cf5a575b6a	true	access.token.claim
64a96539-8f31-4f7e-b374-00cf5a575b6a	clientAddress	claim.name
64a96539-8f31-4f7e-b374-00cf5a575b6a	String	jsonType.label
3ef478cb-9675-4266-81dd-b66d36d2e5c1	clientHost	user.session.note
3ef478cb-9675-4266-81dd-b66d36d2e5c1	true	introspection.token.claim
3ef478cb-9675-4266-81dd-b66d36d2e5c1	true	id.token.claim
3ef478cb-9675-4266-81dd-b66d36d2e5c1	true	access.token.claim
3ef478cb-9675-4266-81dd-b66d36d2e5c1	clientHost	claim.name
3ef478cb-9675-4266-81dd-b66d36d2e5c1	String	jsonType.label
767968ea-8113-44fa-a7fc-88e400ce95e6	client_id	user.session.note
767968ea-8113-44fa-a7fc-88e400ce95e6	true	introspection.token.claim
767968ea-8113-44fa-a7fc-88e400ce95e6	true	id.token.claim
767968ea-8113-44fa-a7fc-88e400ce95e6	true	access.token.claim
767968ea-8113-44fa-a7fc-88e400ce95e6	client_id	claim.name
767968ea-8113-44fa-a7fc-88e400ce95e6	String	jsonType.label
8d021345-00d0-477d-9769-0bcc0f325a94	clientAddress	user.session.note
8d021345-00d0-477d-9769-0bcc0f325a94	true	introspection.token.claim
8d021345-00d0-477d-9769-0bcc0f325a94	true	id.token.claim
8d021345-00d0-477d-9769-0bcc0f325a94	true	access.token.claim
8d021345-00d0-477d-9769-0bcc0f325a94	clientAddress	claim.name
8d021345-00d0-477d-9769-0bcc0f325a94	String	jsonType.label
9613033f-3632-45b5-a3a6-59d7400af061	clientAddress	user.session.note
9613033f-3632-45b5-a3a6-59d7400af061	true	introspection.token.claim
9613033f-3632-45b5-a3a6-59d7400af061	true	id.token.claim
9613033f-3632-45b5-a3a6-59d7400af061	true	access.token.claim
9613033f-3632-45b5-a3a6-59d7400af061	clientAddress	claim.name
9613033f-3632-45b5-a3a6-59d7400af061	String	jsonType.label
b9d4ff45-04f0-4b98-b701-c1b171a40adc	clientHost	user.session.note
b9d4ff45-04f0-4b98-b701-c1b171a40adc	true	introspection.token.claim
b9d4ff45-04f0-4b98-b701-c1b171a40adc	true	id.token.claim
b9d4ff45-04f0-4b98-b701-c1b171a40adc	true	access.token.claim
b9d4ff45-04f0-4b98-b701-c1b171a40adc	clientHost	claim.name
b9d4ff45-04f0-4b98-b701-c1b171a40adc	String	jsonType.label
bc3075d9-c798-4708-afb0-88009ca492b6	client_id	user.session.note
bc3075d9-c798-4708-afb0-88009ca492b6	true	introspection.token.claim
bc3075d9-c798-4708-afb0-88009ca492b6	true	id.token.claim
bc3075d9-c798-4708-afb0-88009ca492b6	true	access.token.claim
bc3075d9-c798-4708-afb0-88009ca492b6	client_id	claim.name
bc3075d9-c798-4708-afb0-88009ca492b6	String	jsonType.label
0c939dcc-86a0-4294-90f8-40a65aa0d25e	clientHost	user.session.note
0c939dcc-86a0-4294-90f8-40a65aa0d25e	true	introspection.token.claim
0c939dcc-86a0-4294-90f8-40a65aa0d25e	true	id.token.claim
0c939dcc-86a0-4294-90f8-40a65aa0d25e	true	access.token.claim
0c939dcc-86a0-4294-90f8-40a65aa0d25e	clientHost	claim.name
0c939dcc-86a0-4294-90f8-40a65aa0d25e	String	jsonType.label
4b8b90c5-8294-4cd4-be89-f624366214c2	client_id	user.session.note
4b8b90c5-8294-4cd4-be89-f624366214c2	true	introspection.token.claim
4b8b90c5-8294-4cd4-be89-f624366214c2	true	id.token.claim
4b8b90c5-8294-4cd4-be89-f624366214c2	true	access.token.claim
4b8b90c5-8294-4cd4-be89-f624366214c2	client_id	claim.name
4b8b90c5-8294-4cd4-be89-f624366214c2	String	jsonType.label
f883759a-86f0-4b0e-a80f-a10386c1db50	clientAddress	user.session.note
f883759a-86f0-4b0e-a80f-a10386c1db50	true	introspection.token.claim
f883759a-86f0-4b0e-a80f-a10386c1db50	true	id.token.claim
f883759a-86f0-4b0e-a80f-a10386c1db50	true	access.token.claim
f883759a-86f0-4b0e-a80f-a10386c1db50	clientAddress	claim.name
f883759a-86f0-4b0e-a80f-a10386c1db50	String	jsonType.label
4cf6b556-9bea-4635-8510-1e144da2897b	clientAddress	user.session.note
4cf6b556-9bea-4635-8510-1e144da2897b	true	introspection.token.claim
4cf6b556-9bea-4635-8510-1e144da2897b	true	id.token.claim
4cf6b556-9bea-4635-8510-1e144da2897b	true	access.token.claim
4cf6b556-9bea-4635-8510-1e144da2897b	clientAddress	claim.name
4cf6b556-9bea-4635-8510-1e144da2897b	String	jsonType.label
7afb2a04-b370-42a0-8026-6779a14f7965	clientHost	user.session.note
7afb2a04-b370-42a0-8026-6779a14f7965	true	introspection.token.claim
7afb2a04-b370-42a0-8026-6779a14f7965	true	id.token.claim
7afb2a04-b370-42a0-8026-6779a14f7965	true	access.token.claim
7afb2a04-b370-42a0-8026-6779a14f7965	clientHost	claim.name
7afb2a04-b370-42a0-8026-6779a14f7965	String	jsonType.label
7daa8d70-c2ff-45a2-849d-c46813e1cb37	client_id	user.session.note
7daa8d70-c2ff-45a2-849d-c46813e1cb37	true	introspection.token.claim
7daa8d70-c2ff-45a2-849d-c46813e1cb37	true	id.token.claim
7daa8d70-c2ff-45a2-849d-c46813e1cb37	true	access.token.claim
7daa8d70-c2ff-45a2-849d-c46813e1cb37	client_id	claim.name
7daa8d70-c2ff-45a2-849d-c46813e1cb37	String	jsonType.label
5af61f5b-b629-4c89-993f-cec8b472d65b	clientHost	user.session.note
5af61f5b-b629-4c89-993f-cec8b472d65b	true	introspection.token.claim
5af61f5b-b629-4c89-993f-cec8b472d65b	true	id.token.claim
5af61f5b-b629-4c89-993f-cec8b472d65b	true	access.token.claim
5af61f5b-b629-4c89-993f-cec8b472d65b	clientHost	claim.name
5af61f5b-b629-4c89-993f-cec8b472d65b	String	jsonType.label
c693cfa7-f2db-4c1a-b944-c4ba1f3509e3	clientAddress	user.session.note
c693cfa7-f2db-4c1a-b944-c4ba1f3509e3	true	introspection.token.claim
c693cfa7-f2db-4c1a-b944-c4ba1f3509e3	true	id.token.claim
c693cfa7-f2db-4c1a-b944-c4ba1f3509e3	true	access.token.claim
c693cfa7-f2db-4c1a-b944-c4ba1f3509e3	clientAddress	claim.name
c693cfa7-f2db-4c1a-b944-c4ba1f3509e3	String	jsonType.label
dbf1f81d-a9b3-44a4-96c7-6f10fc10f187	client_id	user.session.note
dbf1f81d-a9b3-44a4-96c7-6f10fc10f187	true	introspection.token.claim
dbf1f81d-a9b3-44a4-96c7-6f10fc10f187	true	id.token.claim
dbf1f81d-a9b3-44a4-96c7-6f10fc10f187	true	access.token.claim
dbf1f81d-a9b3-44a4-96c7-6f10fc10f187	client_id	claim.name
dbf1f81d-a9b3-44a4-96c7-6f10fc10f187	String	jsonType.label
4e3ca504-e10d-4e23-bdfc-67ea1cd64eef	client_id	user.session.note
4e3ca504-e10d-4e23-bdfc-67ea1cd64eef	true	introspection.token.claim
4e3ca504-e10d-4e23-bdfc-67ea1cd64eef	true	id.token.claim
4e3ca504-e10d-4e23-bdfc-67ea1cd64eef	true	access.token.claim
4e3ca504-e10d-4e23-bdfc-67ea1cd64eef	client_id	claim.name
4e3ca504-e10d-4e23-bdfc-67ea1cd64eef	String	jsonType.label
5160da42-a5a0-40a4-9ef6-3a8a96e2b009	clientHost	user.session.note
5160da42-a5a0-40a4-9ef6-3a8a96e2b009	true	introspection.token.claim
5160da42-a5a0-40a4-9ef6-3a8a96e2b009	true	id.token.claim
5160da42-a5a0-40a4-9ef6-3a8a96e2b009	true	access.token.claim
5160da42-a5a0-40a4-9ef6-3a8a96e2b009	clientHost	claim.name
5160da42-a5a0-40a4-9ef6-3a8a96e2b009	String	jsonType.label
71dbd4ff-d73c-475c-9388-e09e57b7db83	clientAddress	user.session.note
71dbd4ff-d73c-475c-9388-e09e57b7db83	true	introspection.token.claim
71dbd4ff-d73c-475c-9388-e09e57b7db83	true	id.token.claim
71dbd4ff-d73c-475c-9388-e09e57b7db83	true	access.token.claim
71dbd4ff-d73c-475c-9388-e09e57b7db83	clientAddress	claim.name
71dbd4ff-d73c-475c-9388-e09e57b7db83	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
962fdb71-b4bb-438b-80ec-044eefbde5ed	60	300	43200	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	t	f	EXTERNAL	1800	36000	f	f	b48b1bb4-1735-462a-95b3-ffd0f907068f	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	f532034b-33f6-4990-902f-0ab96143fd4b	1fe23664-3168-4d02-a8f3-077cec07ea2f	9102a116-9395-4461-a523-1635819d3d5e	e2603dfe-535c-45b6-9c46-94bde1864957	e09d625d-49b5-4c40-9aa9-0f686349ba87	2592000	f	900	f	t	713d8a40-1850-4df9-b40a-7cab06a3c183	0	f	0	0	750bcd16-aced-4fce-bd44-1d0433981651
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
realmReusableOtpCode	962fdb71-b4bb-438b-80ec-044eefbde5ed	false
cibaBackchannelTokenDeliveryMode	962fdb71-b4bb-438b-80ec-044eefbde5ed	poll
cibaExpiresIn	962fdb71-b4bb-438b-80ec-044eefbde5ed	120
cibaAuthRequestedUserHint	962fdb71-b4bb-438b-80ec-044eefbde5ed	login_hint
parRequestUriLifespan	962fdb71-b4bb-438b-80ec-044eefbde5ed	60
cibaInterval	962fdb71-b4bb-438b-80ec-044eefbde5ed	5
oauth2DeviceCodeLifespan	962fdb71-b4bb-438b-80ec-044eefbde5ed	600
oauth2DevicePollingInterval	962fdb71-b4bb-438b-80ec-044eefbde5ed	5
clientSessionIdleTimeout	962fdb71-b4bb-438b-80ec-044eefbde5ed	0
clientSessionMaxLifespan	962fdb71-b4bb-438b-80ec-044eefbde5ed	0
clientOfflineSessionIdleTimeout	962fdb71-b4bb-438b-80ec-044eefbde5ed	0
clientOfflineSessionMaxLifespan	962fdb71-b4bb-438b-80ec-044eefbde5ed	0
shortVerificationUri	962fdb71-b4bb-438b-80ec-044eefbde5ed	
actionTokenGeneratedByUserLifespan.verify-email	962fdb71-b4bb-438b-80ec-044eefbde5ed	
actionTokenGeneratedByUserLifespan.idp-verify-account-via-email	962fdb71-b4bb-438b-80ec-044eefbde5ed	
actionTokenGeneratedByUserLifespan.reset-credentials	962fdb71-b4bb-438b-80ec-044eefbde5ed	
actionTokenGeneratedByUserLifespan.execute-actions	962fdb71-b4bb-438b-80ec-044eefbde5ed	
displayName	962fdb71-b4bb-438b-80ec-044eefbde5ed	Keycloak
displayNameHtml	962fdb71-b4bb-438b-80ec-044eefbde5ed	<div class="kc-logo-text"><span>Keycloak</span></div>
bruteForceProtected	962fdb71-b4bb-438b-80ec-044eefbde5ed	false
permanentLockout	962fdb71-b4bb-438b-80ec-044eefbde5ed	false
maxFailureWaitSeconds	962fdb71-b4bb-438b-80ec-044eefbde5ed	900
minimumQuickLoginWaitSeconds	962fdb71-b4bb-438b-80ec-044eefbde5ed	60
waitIncrementSeconds	962fdb71-b4bb-438b-80ec-044eefbde5ed	60
quickLoginCheckMilliSeconds	962fdb71-b4bb-438b-80ec-044eefbde5ed	1000
maxDeltaTimeSeconds	962fdb71-b4bb-438b-80ec-044eefbde5ed	43200
failureFactor	962fdb71-b4bb-438b-80ec-044eefbde5ed	30
actionTokenGeneratedByAdminLifespan	962fdb71-b4bb-438b-80ec-044eefbde5ed	43200
actionTokenGeneratedByUserLifespan	962fdb71-b4bb-438b-80ec-044eefbde5ed	300
defaultSignatureAlgorithm	962fdb71-b4bb-438b-80ec-044eefbde5ed	RS256
offlineSessionMaxLifespanEnabled	962fdb71-b4bb-438b-80ec-044eefbde5ed	false
offlineSessionMaxLifespan	962fdb71-b4bb-438b-80ec-044eefbde5ed	5184000
webAuthnPolicyRpEntityName	962fdb71-b4bb-438b-80ec-044eefbde5ed	keycloak
webAuthnPolicySignatureAlgorithms	962fdb71-b4bb-438b-80ec-044eefbde5ed	ES256
webAuthnPolicyRpId	962fdb71-b4bb-438b-80ec-044eefbde5ed	
webAuthnPolicyAttestationConveyancePreference	962fdb71-b4bb-438b-80ec-044eefbde5ed	not specified
webAuthnPolicyAuthenticatorAttachment	962fdb71-b4bb-438b-80ec-044eefbde5ed	not specified
webAuthnPolicyRequireResidentKey	962fdb71-b4bb-438b-80ec-044eefbde5ed	not specified
webAuthnPolicyUserVerificationRequirement	962fdb71-b4bb-438b-80ec-044eefbde5ed	not specified
webAuthnPolicyCreateTimeout	962fdb71-b4bb-438b-80ec-044eefbde5ed	0
webAuthnPolicyAvoidSameAuthenticatorRegister	962fdb71-b4bb-438b-80ec-044eefbde5ed	false
webAuthnPolicyRpEntityNamePasswordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	ES256
webAuthnPolicyRpIdPasswordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	
webAuthnPolicyAttestationConveyancePreferencePasswordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	not specified
webAuthnPolicyRequireResidentKeyPasswordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	not specified
webAuthnPolicyCreateTimeoutPasswordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	false
client-policies.profiles	962fdb71-b4bb-438b-80ec-044eefbde5ed	{"profiles":[]}
client-policies.policies	962fdb71-b4bb-438b-80ec-044eefbde5ed	{"policies":[]}
_browser_header.contentSecurityPolicyReportOnly	962fdb71-b4bb-438b-80ec-044eefbde5ed	
_browser_header.xContentTypeOptions	962fdb71-b4bb-438b-80ec-044eefbde5ed	nosniff
_browser_header.referrerPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	no-referrer
_browser_header.xRobotsTag	962fdb71-b4bb-438b-80ec-044eefbde5ed	none
_browser_header.xFrameOptions	962fdb71-b4bb-438b-80ec-044eefbde5ed	SAMEORIGIN
_browser_header.contentSecurityPolicy	962fdb71-b4bb-438b-80ec-044eefbde5ed	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	962fdb71-b4bb-438b-80ec-044eefbde5ed	1; mode=block
_browser_header.strictTransportSecurity	962fdb71-b4bb-438b-80ec-044eefbde5ed	max-age=31536000; includeSubDomains
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
962fdb71-b4bb-438b-80ec-044eefbde5ed	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	962fdb71-b4bb-438b-80ec-044eefbde5ed
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.redirect_uris (client_id, value) FROM stdin;
294ab06e-9ea6-48c3-8166-59b00af63675	/realms/master/account/*
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	/realms/master/account/*
e1eabf61-45a2-4b63-936d-d1ce68866ada	/admin/master/console/*
c758c45c-a01d-4800-b5d2-dfde4a30a492	/*
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
7e3e381a-acc3-4b42-91b9-fdc404d37396	VERIFY_EMAIL	Verify Email	962fdb71-b4bb-438b-80ec-044eefbde5ed	t	f	VERIFY_EMAIL	50
d8fc9593-9ee2-4f01-b5e5-bf1e03364b32	UPDATE_PROFILE	Update Profile	962fdb71-b4bb-438b-80ec-044eefbde5ed	t	f	UPDATE_PROFILE	40
96fb8a7b-4cc7-4341-9775-f5d13585b555	CONFIGURE_TOTP	Configure OTP	962fdb71-b4bb-438b-80ec-044eefbde5ed	t	f	CONFIGURE_TOTP	10
6e38db25-d99b-4068-b4d4-a8aa64b6fbaf	UPDATE_PASSWORD	Update Password	962fdb71-b4bb-438b-80ec-044eefbde5ed	t	f	UPDATE_PASSWORD	30
92d84de9-3529-415a-a823-6e385af2267b	TERMS_AND_CONDITIONS	Terms and Conditions	962fdb71-b4bb-438b-80ec-044eefbde5ed	f	f	TERMS_AND_CONDITIONS	20
77b5cd7c-c230-430b-b9a3-dcaf52b00920	delete_account	Delete Account	962fdb71-b4bb-438b-80ec-044eefbde5ed	f	f	delete_account	60
e603ad2f-efa1-4b9a-81ce-eb09d85e69eb	update_user_locale	Update User Locale	962fdb71-b4bb-438b-80ec-044eefbde5ed	t	f	update_user_locale	1000
bd425d02-18c4-41d8-ac80-0a4384a64c90	webauthn-register	Webauthn Register	962fdb71-b4bb-438b-80ec-044eefbde5ed	t	f	webauthn-register	70
2d460894-9f55-436f-a662-288b90cb1ecc	webauthn-register-passwordless	Webauthn Register Passwordless	962fdb71-b4bb-438b-80ec-044eefbde5ed	t	f	webauthn-register-passwordless	80
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
c758c45c-a01d-4800-b5d2-dfde4a30a492	t	0	1
f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	t	0	1
352ef396-c83f-4ed8-8c47-23cc928864aa	t	0	1
2c111030-ed95-40ff-9976-12c8cd399083	t	0	1
6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	t	0	1
b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	t	0	1
009f96bb-01ae-4ec5-93b5-88853bc82364	t	0	1
5c13758d-f499-47ee-94cf-c97563dcb644	t	0	1
4d0ebf75-767a-4542-bbbe-7910f9096a7d	t	0	1
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
e4cd3c3a-b093-40aa-9bb4-2bb2d8ec9a62	Default Policy	A policy that grants access only for users within this realm	js	0	0	c758c45c-a01d-4800-b5d2-dfde4a30a492	\N
78aac6ea-271f-4a33-860e-37f9a9da06bb	Default Permission	A permission that applies to the default resource type	resource	1	0	c758c45c-a01d-4800-b5d2-dfde4a30a492	\N
b6334ce6-a38e-4c63-a834-c04917885c4e	Default Policy	A policy that grants access only for users within this realm	js	0	0	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	\N
5e886ca6-0cf6-47fb-8cfd-c14d2e323ae5	Default Permission	A permission that applies to the default resource type	resource	1	0	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	\N
73b631ec-69cd-4a9d-9568-130374c0e5c0	Default Permission	A permission that applies to the default resource type	resource	1	0	2c111030-ed95-40ff-9976-12c8cd399083	\N
67cbece1-f2be-404f-90fb-ae7af173b61e	Default Policy	A policy that grants access only for users within this realm	js	0	0	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	\N
aedc057b-7202-46f5-9478-7ef82f0e3a54	Default Permission	A permission that applies to the default resource type	resource	1	0	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	\N
ea8535a9-b65d-4012-a40a-b1bdd73b29b1	Default Policy	A policy that grants access only for users within this realm	js	0	0	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	\N
7daf3601-074b-4ab9-babe-6c4712df1a99	Default Permission	A permission that applies to the default resource type	resource	1	0	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	\N
6a1dba2e-1e31-4673-aaf7-44a705f8793d	Default Policy	A policy that grants access only for users within this realm	js	0	0	009f96bb-01ae-4ec5-93b5-88853bc82364	\N
1cb8b12c-78f4-4090-a0ea-89f070199e16	Default Permission	A permission that applies to the default resource type	resource	1	0	009f96bb-01ae-4ec5-93b5-88853bc82364	\N
6ecddc8f-729b-4b64-93be-e851e345c0fc	Default Policy	A policy that grants access only for users within this realm	js	0	0	352ef396-c83f-4ed8-8c47-23cc928864aa	\N
fd00e3d6-ed90-4faa-b279-ed8da558fdb1	Default Permission	A permission that applies to the default resource type	resource	1	0	352ef396-c83f-4ed8-8c47-23cc928864aa	\N
e65221f4-8bce-4074-a82d-deb6af0bb80f	Default Policy	A policy that grants access only for users within this realm	js	0	0	2c111030-ed95-40ff-9976-12c8cd399083	\N
456adab1-163b-42ed-81a3-dd5dfa87aba2	Default Policy	A policy that grants access only for users within this realm	js	0	0	5c13758d-f499-47ee-94cf-c97563dcb644	\N
bc89b137-11a8-42d4-9128-189775120a67	Default Permission	A permission that applies to the default resource type	resource	1	0	5c13758d-f499-47ee-94cf-c97563dcb644	\N
f874c5ea-c81b-4dc1-87c6-3b70d355dec3	Default Policy	A policy that grants access only for users within this realm	js	0	0	4d0ebf75-767a-4542-bbbe-7910f9096a7d	\N
c2a5d1a5-f3c5-4c62-84e4-4a4838523125	Default Permission	A permission that applies to the default resource type	resource	1	0	4d0ebf75-767a-4542-bbbe-7910f9096a7d	\N
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
def9bb74-0f1a-458e-92c7-1a0179963260	Default Resource	urn:gaian:resources:default	\N	c758c45c-a01d-4800-b5d2-dfde4a30a492	c758c45c-a01d-4800-b5d2-dfde4a30a492	f	\N
69c3ec6d-83df-49a5-aa16-e206a91c14ce	Default Resource	urn:HOLACRACY:resources:default	\N	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	f	\N
36c43d19-4e07-4c96-a53d-a73da412e4f2	Default Resource	urn:mllmi:resources:default	\N	352ef396-c83f-4ed8-8c47-23cc928864aa	352ef396-c83f-4ed8-8c47-23cc928864aa	f	\N
63df819a-5819-4cdb-bd92-90130b61fbac	Default Resource	urn:bbemk:resources:default	\N	2c111030-ed95-40ff-9976-12c8cd399083	2c111030-ed95-40ff-9976-12c8cd399083	f	\N
20f6fb50-d3d3-4fae-9bc1-80ff60ebecdf	Default Resource	urn:fkdkj:resources:default	\N	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	f	\N
38e663cc-2102-428b-af1a-2793de168e89	Default Resource	urn:hmeid:resources:default	\N	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	f	\N
d8919d40-0f35-4164-b1df-2c89c39a2426	Default Resource	urn:jhjla:resources:default	\N	009f96bb-01ae-4ec5-93b5-88853bc82364	009f96bb-01ae-4ec5-93b5-88853bc82364	f	\N
a5ef55aa-4b9b-44e6-857c-21bcce520077	Default Resource	urn:lkfjj:resources:default	\N	5c13758d-f499-47ee-94cf-c97563dcb644	5c13758d-f499-47ee-94cf-c97563dcb644	f	\N
893077d9-9bc6-4041-82a4-6629cc395094	Default Resource	urn:dgjjh:resources:default	\N	4d0ebf75-767a-4542-bbbe-7910f9096a7d	4d0ebf75-767a-4542-bbbe-7910f9096a7d	f	\N
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.resource_uris (resource_id, value) FROM stdin;
def9bb74-0f1a-458e-92c7-1a0179963260	/*
69c3ec6d-83df-49a5-aa16-e206a91c14ce	/*
36c43d19-4e07-4c96-a53d-a73da412e4f2	/*
63df819a-5819-4cdb-bd92-90130b61fbac	/*
20f6fb50-d3d3-4fae-9bc1-80ff60ebecdf	/*
38e663cc-2102-428b-af1a-2793de168e89	/*
d8919d40-0f35-4164-b1df-2c89c39a2426	/*
a5ef55aa-4b9b-44e6-857c-21bcce520077	/*
893077d9-9bc6-4041-82a4-6629cc395094	/*
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	03dac675-0d0e-467d-b30b-608ac6d834f6
7d95546a-c3b7-410a-8bb0-fbb3eb99af76	147c66c3-511f-49c0-8552-d174b1dff0e5
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_attribute (name, value, user_id, id) FROM stdin;
userType	TENANT	ad05207a-4c5b-4276-9bb3-1a6a23ded218	50f11a9d-01bb-44cd-93b7-82272622e6fe
userType	TENANT	a6907889-1c60-4e0f-9986-fc6fb6c4ff87	486bd815-8e3a-437f-b9f0-4ed4878c18c8
userType	TENANT	04bbcce2-1e1f-474b-8249-4f1631bfcac9	0fc3bb5c-426f-499e-bfa0-cb1c5bf321bd
userType	TENANT	bb7dddf8-68f3-44d8-b52e-14c17a631ee1	035add8b-aa9a-401e-9450-9327bf09c7e3
userType	TENANT	c66b50c9-eb41-47ca-b9a9-290c1df4fea3	54bb05f0-6d90-406b-a0a9-4efeeb04deab
userType	TENANT	6e9d0fb9-2e33-40c2-ae9d-f710215a442e	88692a15-e6c0-418c-80f8-2862541763e9
userType	TENANT	8a088e82-6021-4bb3-b7e2-ff6f16583a94	8467b33f-4466-4002-b7d1-1f6b5f1283eb
userType	TENANT	311ef274-ab20-4e81-8526-b4c5fa623d2f	65e2e51b-c2bc-42c1-a553-4e855fc1961a
userType	TENANT	6d984476-fbed-4c44-a3e1-a9004bfb6feb	f91e1bb6-9eb6-4994-8b09-7e0cf9925c69
userType	TENANT	50557830-c2d0-425f-8e35-59023f35a7b7	b56148f8-0d1a-43ff-804d-7465a619439d
userType	TENANT	05d532eb-ff53-4ff4-850c-ec26bf24bbf8	22931cb2-f687-4ca0-b774-4c278fccc6df
userType	TENANT	f60a4d74-c389-4119-879f-0706f76da826	a2de61b7-2424-4679-86ad-f972885bc351
userType	TENANT	2d637b27-36ca-4980-9f76-20b7d7aeb1cc	50c4b767-cfcb-406a-a953-12fdef878cf8
userType	TENANT	e3e98db2-aa56-4580-b77e-942f801f1fb6	c657f453-9512-4985-916c-39830339bd4e
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
882c94a4-7697-46d2-9a74-a9960f11ecda	\N	9c9e4ff6-fc66-4d3b-b4e7-60204b40b9ae	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	admin	1715522200976	\N	0
ab0bfcff-8a4f-4bc4-a849-14f8aa51cb68	\N	bf92b7c7-80dc-4b7b-858a-48f8ee33bbf1	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	service-account-gaian	1715667331141	c758c45c-a01d-4800-b5d2-dfde4a30a492	0
26d7f0a8-551f-4a26-afe8-e251e4743807	\N	963f643e-e965-4531-aae9-ecc26cd62058	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	service-account-holacracy	1715667921023	f2a17e8c-c240-4c02-96bc-33ebfd6d53bd	0
f60a4d74-c389-4119-879f-0706f76da826	a7zhwp22zl@gatestautomation.com	b65dbafa-269a-4fd2-8b00-8e48da401c31	t	t	\N	ggdal	hmdbm	962fdb71-b4bb-438b-80ec-044eefbde5ed	jhjla	1715677940909	\N	0
ad05207a-4c5b-4276-9bb3-1a6a23ded218	tjcdlc1wok@gatestautomation.com	cac3ca4d-258f-44da-9964-befc403e3432	t	t	\N	lbagl	Smgmcc	962fdb71-b4bb-438b-80ec-044eefbde5ed	aadam	1715668389715	\N	0
82610b82-328e-427d-be7b-cd2a8074c9a8	\N	694651c2-987a-4920-bec5-55bfc645fc65	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	service-account-a7zhwp22zl@gatestautomation.com	1715677945531	009f96bb-01ae-4ec5-93b5-88853bc82364	0
a6907889-1c60-4e0f-9986-fc6fb6c4ff87	3rfed@gatestautomation.com	3264a155-b844-4bdc-8160-550d772e748d	t	t	\N	tenan	tenan	962fdb71-b4bb-438b-80ec-044eefbde5ed	tenan	1715668624241	\N	0
04bbcce2-1e1f-474b-8249-4f1631bfcac9	qpeogdtm5z@gatestautomation.com	23c73fed-1b89-4e27-8fcd-7581cf7c8213	t	t	\N	fmaej	Sblcee	962fdb71-b4bb-438b-80ec-044eefbde5ed	gmjdm	1715668913118	\N	0
2d637b27-36ca-4980-9f76-20b7d7aeb1cc	v26rjofvk7@gatestautomation.com	cdee79e7-409b-42bc-8a4d-27dbed334c07	t	t	\N	baimd	mdgkj	962fdb71-b4bb-438b-80ec-044eefbde5ed	lkfjj	1715678072833	\N	0
2772e165-9135-42e9-a22a-1649eb34b3d8	\N	aae734d9-e835-4eba-ba40-d1fdcc277c45	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	service-account-v26rjofvk7@gatestautomation.com	1715678077223	5c13758d-f499-47ee-94cf-c97563dcb644	0
bb7dddf8-68f3-44d8-b52e-14c17a631ee1	ff@gatestautomation.com	d7253562-9952-48f5-950b-fb33af50ae00	t	t	\N	test1	test1	962fdb71-b4bb-438b-80ec-044eefbde5ed	test1	1715669145131	\N	0
c66b50c9-eb41-47ca-b9a9-290c1df4fea3	ffr@gatestautomation.com	a7e160d3-acba-4b86-aad6-00c1449f48f8	t	t	\N	test12	test1	962fdb71-b4bb-438b-80ec-044eefbde5ed	test12	1715669646691	\N	0
e3e98db2-aa56-4580-b77e-942f801f1fb6	vobjonluqe@gatestautomation.com	92619af7-5fda-4e9d-8eb9-ef5a8d21d9c6	t	t	\N	mjiih	klljk	962fdb71-b4bb-438b-80ec-044eefbde5ed	dgjjh	1715678112894	\N	0
fcacc0ea-bc08-4021-b4a0-360404a9f096	\N	ea8eeb59-9395-49d9-9be7-9eafb5a2a72c	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	service-account-vobjonluqe@gatestautomation.com	1715678117329	4d0ebf75-767a-4542-bbbe-7910f9096a7d	0
311ef274-ab20-4e81-8526-b4c5fa623d2f	uhknll9zzu@gatestautomation.com	956d7ca3-57d2-4305-8f28-27c397ce3191	t	t	\N	hijeg	mcgbd	962fdb71-b4bb-438b-80ec-044eefbde5ed	bbemk	1715677449861	\N	0
6e9d0fb9-2e33-40c2-ae9d-f710215a442e	kvrshs1byy@gatestautomation.com	eeb2297e-9416-4ec5-9fb8-1425dfd65905	t	t	\N	mdaih	aebbm	962fdb71-b4bb-438b-80ec-044eefbde5ed	mllmi	1715672995040	\N	0
d0d70bdf-fb52-4570-8897-f1f928957563	\N	0aaec283-5b9e-49c4-953a-4dbe08ceed38	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	service-account-kvrshs1byy@gatestautomation.com	1715672999980	352ef396-c83f-4ed8-8c47-23cc928864aa	0
8a088e82-6021-4bb3-b7e2-ff6f16583a94	df@gatestautomation.com	96c88292-af6c-4aef-b382-87602b5b1c8f	t	t	\N	test1233	test1	962fdb71-b4bb-438b-80ec-044eefbde5ed	test1442	1715673876060	\N	0
9964e2ba-e593-4746-ae2a-d3ffe17f2b4e	\N	df6ed3c6-9106-40e2-94be-4f481c1134cc	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	service-account-uhknll9zzu@gatestautomation.com	1715677454962	2c111030-ed95-40ff-9976-12c8cd399083	0
6d984476-fbed-4c44-a3e1-a9004bfb6feb	bvv@gatestautomation.com	7c0d1155-4593-4104-bdea-3ee127354d02	t	t	\N	test12dd33	test1	962fdb71-b4bb-438b-80ec-044eefbde5ed	test1dd442	1715677482878	\N	0
50557830-c2d0-425f-8e35-59023f35a7b7	l1jglt50hj@gatestautomation.com	ceb40279-8be2-4890-8598-a1c6d8e43b2b	t	t	\N	gmadg	mbbfg	962fdb71-b4bb-438b-80ec-044eefbde5ed	fkdkj	1715677555146	\N	0
4ac71828-d8c2-4c98-8559-b297ed04466e	\N	0a0928ef-af94-41cd-8c37-2d791a68ab68	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	service-account-l1jglt50hj@gatestautomation.com	1715677559506	6766fa3c-f1bd-4bfe-b5b9-5bc1b04f523c	0
05d532eb-ff53-4ff4-850c-ec26bf24bbf8	48myrsiodx@gatestautomation.com	cbc59668-6514-4b3b-aac1-2ab3d39d9fe1	t	t	\N	cijif	failk	962fdb71-b4bb-438b-80ec-044eefbde5ed	hmeid	1715677752501	\N	0
6c048098-5291-49c3-bee1-06abeb7f6a99	\N	1c2a0fb9-88b1-4661-843f-525e6c7b7c62	f	t	\N	\N	\N	962fdb71-b4bb-438b-80ec-044eefbde5ed	service-account-48myrsiodx@gatestautomation.com	1715677757101	b0526a04-ec0d-4b39-b5e6-7a22cf9c83dc	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_group_membership (group_id, user_id) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
750bcd16-aced-4fce-bd44-1d0433981651	882c94a4-7697-46d2-9a74-a9960f11ecda
a53bb093-34f1-4b39-b476-988513f41669	882c94a4-7697-46d2-9a74-a9960f11ecda
750bcd16-aced-4fce-bd44-1d0433981651	ab0bfcff-8a4f-4bc4-a849-14f8aa51cb68
aaa780ef-c923-4c67-add2-20049b03f350	ab0bfcff-8a4f-4bc4-a849-14f8aa51cb68
750bcd16-aced-4fce-bd44-1d0433981651	26d7f0a8-551f-4a26-afe8-e251e4743807
2ce99a16-fd1f-4729-bd5e-43b20c67d44c	26d7f0a8-551f-4a26-afe8-e251e4743807
750bcd16-aced-4fce-bd44-1d0433981651	ad05207a-4c5b-4276-9bb3-1a6a23ded218
750bcd16-aced-4fce-bd44-1d0433981651	a6907889-1c60-4e0f-9986-fc6fb6c4ff87
750bcd16-aced-4fce-bd44-1d0433981651	04bbcce2-1e1f-474b-8249-4f1631bfcac9
750bcd16-aced-4fce-bd44-1d0433981651	bb7dddf8-68f3-44d8-b52e-14c17a631ee1
750bcd16-aced-4fce-bd44-1d0433981651	c66b50c9-eb41-47ca-b9a9-290c1df4fea3
750bcd16-aced-4fce-bd44-1d0433981651	6e9d0fb9-2e33-40c2-ae9d-f710215a442e
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	6e9d0fb9-2e33-40c2-ae9d-f710215a442e
750bcd16-aced-4fce-bd44-1d0433981651	d0d70bdf-fb52-4570-8897-f1f928957563
5d81b2af-cd46-42c8-aa99-d47c49c4d4be	d0d70bdf-fb52-4570-8897-f1f928957563
750bcd16-aced-4fce-bd44-1d0433981651	8a088e82-6021-4bb3-b7e2-ff6f16583a94
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	8a088e82-6021-4bb3-b7e2-ff6f16583a94
750bcd16-aced-4fce-bd44-1d0433981651	311ef274-ab20-4e81-8526-b4c5fa623d2f
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	311ef274-ab20-4e81-8526-b4c5fa623d2f
750bcd16-aced-4fce-bd44-1d0433981651	9964e2ba-e593-4746-ae2a-d3ffe17f2b4e
1f227b2a-85fb-4984-880e-34dde6aa37b4	9964e2ba-e593-4746-ae2a-d3ffe17f2b4e
750bcd16-aced-4fce-bd44-1d0433981651	6d984476-fbed-4c44-a3e1-a9004bfb6feb
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	6d984476-fbed-4c44-a3e1-a9004bfb6feb
750bcd16-aced-4fce-bd44-1d0433981651	50557830-c2d0-425f-8e35-59023f35a7b7
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	50557830-c2d0-425f-8e35-59023f35a7b7
750bcd16-aced-4fce-bd44-1d0433981651	4ac71828-d8c2-4c98-8559-b297ed04466e
f9d4ace7-c619-4a1f-a0e3-1113d8e5d31f	4ac71828-d8c2-4c98-8559-b297ed04466e
750bcd16-aced-4fce-bd44-1d0433981651	05d532eb-ff53-4ff4-850c-ec26bf24bbf8
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	05d532eb-ff53-4ff4-850c-ec26bf24bbf8
750bcd16-aced-4fce-bd44-1d0433981651	6c048098-5291-49c3-bee1-06abeb7f6a99
5d4df64f-51eb-4214-b9f1-eb3f8c991978	6c048098-5291-49c3-bee1-06abeb7f6a99
750bcd16-aced-4fce-bd44-1d0433981651	f60a4d74-c389-4119-879f-0706f76da826
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	f60a4d74-c389-4119-879f-0706f76da826
750bcd16-aced-4fce-bd44-1d0433981651	82610b82-328e-427d-be7b-cd2a8074c9a8
09c9fddb-944d-458a-aeed-8c4e9771aa72	82610b82-328e-427d-be7b-cd2a8074c9a8
750bcd16-aced-4fce-bd44-1d0433981651	2d637b27-36ca-4980-9f76-20b7d7aeb1cc
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	2d637b27-36ca-4980-9f76-20b7d7aeb1cc
750bcd16-aced-4fce-bd44-1d0433981651	2772e165-9135-42e9-a22a-1649eb34b3d8
29654c7c-f86d-4e90-8c2f-98212b3b4c59	2772e165-9135-42e9-a22a-1649eb34b3d8
750bcd16-aced-4fce-bd44-1d0433981651	e3e98db2-aa56-4580-b77e-942f801f1fb6
e92c76e9-de3d-4d2d-b0a5-4132cd47d341	e3e98db2-aa56-4580-b77e-942f801f1fb6
750bcd16-aced-4fce-bd44-1d0433981651	fcacc0ea-bc08-4021-b4a0-360404a9f096
e7698f94-85ac-4bd2-9c4a-1aa3dd809bd6	fcacc0ea-bc08-4021-b4a0-360404a9f096
\.


--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_session (id, auth_method, ip_address, last_session_refresh, login_username, realm_id, remember_me, started, user_id, user_session_state, broker_session_id, broker_user_id) FROM stdin;
\.


--
-- Data for Name: user_session_note; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.user_session_note (user_session, name, value) FROM stdin;
\.


--
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: gaian
--

COPY public.web_origins (client_id, value) FROM stdin;
e1eabf61-45a2-4b63-936d-d1ce68866ada	+
c758c45c-a01d-4800-b5d2-dfde4a30a492	/*
\.


--
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: client_user_session_note constr_cl_usr_ses_note; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT constr_cl_usr_ses_note PRIMARY KEY (client_session, name);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: client_session_role constraint_5; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT constraint_5 PRIMARY KEY (client_session, role_id);


--
-- Name: user_session constraint_57; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_session
    ADD CONSTRAINT constraint_57 PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client_session_note constraint_5e; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT constraint_5e PRIMARY KEY (client_session, name);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: client_session constraint_8; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT constraint_8 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: client_session_auth_status constraint_auth_status_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT constraint_auth_status_pk PRIMARY KEY (client_session, authenticator);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: client_session_prot_mapper constraint_cs_pmp_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT constraint_cs_pmp_pk PRIMARY KEY (client_session, protocol_mapper_id);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: user_session_note constraint_usn_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT constraint_usn_pk PRIMARY KEY (user_session, name);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_jkuwuvd56ontgsuhogm8uewrt; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_jkuwuvd56ontgsuhogm8uewrt UNIQUE (client_id, client_storage_provider, external_client_id, user_id);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_client_session_session; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_client_session_session ON public.client_session USING btree (session_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_css_preload; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_offline_css_preload ON public.offline_client_session USING btree (client_id, offline_flag);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_offline_uss_by_usersess; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_offline_uss_by_usersess ON public.offline_user_session USING btree (realm_id, offline_flag, user_session_id);


--
-- Name: idx_offline_uss_createdon; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_offline_uss_createdon ON public.offline_user_session USING btree (created_on);


--
-- Name: idx_offline_uss_preload; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_offline_uss_preload ON public.offline_user_session USING btree (offline_flag, created_on, user_session_id);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_us_sess_id_on_cl_sess; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_us_sess_id_on_cl_sess ON public.offline_client_session USING btree (user_session_id);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: gaian
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: client_session_auth_status auth_status_constraint; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session_auth_status
    ADD CONSTRAINT auth_status_constraint FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: client_session_note fk5edfb00ff51c2736; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session_note
    ADD CONSTRAINT fk5edfb00ff51c2736 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: user_session_note fk5edfb00ff51d3472; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_session_note
    ADD CONSTRAINT fk5edfb00ff51d3472 FOREIGN KEY (user_session) REFERENCES public.user_session(id);


--
-- Name: client_session_role fk_11b7sgqw18i532811v7o2dv76; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session_role
    ADD CONSTRAINT fk_11b7sgqw18i532811v7o2dv76 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session_prot_mapper fk_33a8sgqw18i532811v7o2dk89; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session_prot_mapper
    ADD CONSTRAINT fk_33a8sgqw18i532811v7o2dk89 FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_session fk_b4ao2vcvat6ukau74wbwtfqo1; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_session
    ADD CONSTRAINT fk_b4ao2vcvat6ukau74wbwtfqo1 FOREIGN KEY (session_id) REFERENCES public.user_session(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_user_session_note fk_cl_usr_ses_note; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_user_session_note
    ADD CONSTRAINT fk_cl_usr_ses_note FOREIGN KEY (client_session) REFERENCES public.client_session(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: gaian
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

